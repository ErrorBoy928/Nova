"""
ui/tasks_dialog.py

Dedicated, sleek Obsidian Dark dialog for reviewing, resuming, and managing
autonomous Agent Tasks & Saved Goals.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

import memory.database as db

_BG_BLACK = "#09090b"
_BG_PANEL = "#111116"
_BG_CARD = "#14141b"
_BORDER = "#22222b"
_ACCENT_BLUE = "#2563eb"
_ACCENT_CYAN = "#38bdf8"
_ACCENT_GREEN = "#10b981"
_ACCENT_RED = "#ef4444"
_TEXT_MAIN = "#f8fafc"
_TEXT_MUTED = "#94a3b8"


class TasksDialog(QDialog):
    resume_task_requested = Signal(str, str)  # (task_id, next_prompt)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("📋 Saved Agent Tasks & Goals - Nova AI")
        self.setFixedSize(580, 520)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {_BG_BLACK};
                color: {_TEXT_MAIN};
            }}
        """)
        self._build_ui()
        self._load_tasks()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)

        # Header Title
        title_box = QVBoxLayout()
        title_box.setSpacing(3)
        title_lbl = QLabel("📋 Autonomous Agent Tasks & Goals")
        title_lbl.setStyleSheet(f"font-size: 16px; font-weight: 800; color: {_TEXT_MAIN};")
        title_box.addWidget(title_lbl)

        sub_lbl = QLabel("Multi-step workflows and complex jobs saved and managed by Nova AI.")
        sub_lbl.setStyleSheet(f"font-size: 11px; color: {_TEXT_MUTED};")
        title_box.addWidget(sub_lbl)
        layout.addLayout(title_box)

        # Scroll area for tasks
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet(f"""
            QScrollArea {{
                background: {_BG_PANEL};
                border: 1px solid {_BORDER};
                border-radius: 8px;
            }}
        """)
        self.container = QWidget()
        self.container.setStyleSheet("background: transparent;")
        self.tasks_layout = QVBoxLayout(self.container)
        self.tasks_layout.setContentsMargins(10, 10, 10, 10)
        self.tasks_layout.setSpacing(10)
        self.tasks_layout.addStretch()
        self.scroll.setWidget(self.container)
        layout.addWidget(self.scroll, 1)

        # Footer Actions
        footer = QHBoxLayout()
        footer.setSpacing(8)

        clear_btn = QPushButton("Clear Completed")
        clear_btn.setFixedHeight(30)
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: 1px solid {_BORDER};
                border-radius: 6px;
                color: {_TEXT_MUTED};
                font-size: 11px;
                padding: 0 12px;
            }}
            QPushButton:hover {{
                border-color: {_ACCENT_RED};
                color: {_ACCENT_RED};
            }}
        """)
        clear_btn.clicked.connect(self._clear_completed)
        footer.addWidget(clear_btn)

        footer.addStretch()

        close_btn = QPushButton("Close")
        close_btn.setFixedHeight(30)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: #171722;
                border: 1px solid {_BORDER};
                border-radius: 6px;
                color: {_TEXT_MAIN};
                font-size: 11px;
                font-weight: 600;
                padding: 0 18px;
            }}
            QPushButton:hover {{
                border-color: {_ACCENT_CYAN};
                color: #ffffff;
            }}
        """)
        close_btn.clicked.connect(self.accept)
        footer.addWidget(close_btn)

        layout.addLayout(footer)

    def _load_tasks(self):
        # Clear existing
        while self.tasks_layout.count() > 1:
            item = self.tasks_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        tasks = db.get_all_agent_tasks(limit=40)
        if not tasks:
            empty_lbl = QLabel("No saved tasks yet.\nAssign any big or multi-step goal to Nova and it will be saved here automatically.")
            empty_lbl.setAlignment(Qt.AlignCenter)
            empty_lbl.setStyleSheet(f"color: {_TEXT_MUTED}; font-size: 12px; padding: 40px 10px;")
            self.tasks_layout.insertWidget(0, empty_lbl)
            return

        for t in tasks:
            card = self._create_task_card(t)
            self.tasks_layout.insertWidget(self.tasks_layout.count() - 1, card)

    def _create_task_card(self, task: dict) -> QFrame:
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background-color: {_BG_CARD};
                border: 1px solid {_BORDER};
                border-radius: 8px;
            }}
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)

        # Header Row: Title & Status
        h_row = QHBoxLayout()
        h_row.setSpacing(8)

        title_lbl = QLabel(task["title"])
        title_lbl.setStyleSheet(f"font-size: 13px; font-weight: 700; color: {_TEXT_MAIN};")
        h_row.addWidget(title_lbl, 1)

        is_done = (task["status"] == "completed")
        status_color = _ACCENT_GREEN if is_done else _ACCENT_CYAN
        status_bg = "#032e22" if is_done else "#082f49"
        status_border = "#059669" if is_done else "#0284c7"

        status_badge = QLabel(task["status"].upper())
        status_badge.setStyleSheet(f"""
            background-color: {status_bg};
            color: {status_color};
            border: 1px solid {status_border};
            border-radius: 4px;
            font-size: 9px;
            font-weight: 800;
            padding: 2px 6px;
        """)
        h_row.addWidget(status_badge)
        layout.addLayout(h_row)

        # Steps progress
        steps = task.get("steps", [])
        total_steps = len(steps)
        current_step = task.get("current_step", 0)

        if total_steps > 0:
            pct = 100 if is_done else int((current_step / total_steps) * 100)
            pbar = QProgressBar()
            pbar.setFixedHeight(5)
            pbar.setTextVisible(False)
            pbar.setValue(pct)
            pbar.setStyleSheet(f"""
                QProgressBar {{
                    background-color: #09090d;
                    border: none;
                    border-radius: 2px;
                }}
                QProgressBar::chunk {{
                    background-color: {status_color};
                    border-radius: 2px;
                }}
            """)
            layout.addWidget(pbar)

            # Step Checklist preview
            steps_box = QVBoxLayout()
            steps_box.setSpacing(2)
            for idx, st in enumerate(steps):
                if idx < current_step or is_done:
                    icon_tag = "✓"
                    st_style = "color: #64748b; text-decoration: line-through; font-size: 11px;"
                elif idx == current_step:
                    icon_tag = "●"
                    st_style = f"color: {_ACCENT_CYAN}; font-weight: 600; font-size: 11px;"
                else:
                    icon_tag = "○"
                    st_style = f"color: {_TEXT_MUTED}; font-size: 11px;"

                st_lbl = QLabel(f"{icon_tag} Step {idx + 1}: {st}")
                st_lbl.setStyleSheet(st_style)
                steps_box.addWidget(st_lbl)
            layout.addLayout(steps_box)

        # Action Buttons
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(0, 4, 0, 0)
        btn_row.setSpacing(6)

        if not is_done:
            next_step_name = steps[current_step] if current_step < len(steps) else "Finish task"
            resume_btn = QPushButton("▶ Run Next Step")
            resume_btn.setFixedHeight(24)
            resume_btn.setCursor(Qt.PointingHandCursor)
            resume_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #032e22;
                    color: #6ee7b7;
                    border: 1px solid #059669;
                    border-radius: 4px;
                    font-size: 10px;
                    font-weight: 700;
                    padding: 0 10px;
                }}
                QPushButton:hover {{
                    background-color: #047857;
                }}
            """)
            task_id = task["id"]
            resume_btn.clicked.connect(lambda checked=False, tid=task_id, st=next_step_name: self._on_resume_step(tid, st))
            btn_row.addWidget(resume_btn)

            done_btn = QPushButton("✓ Mark Done")
            done_btn.setFixedHeight(24)
            done_btn.setCursor(Qt.PointingHandCursor)
            done_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #15151f;
                    color: {_TEXT_MUTED};
                    border: 1px solid {_BORDER};
                    border-radius: 4px;
                    font-size: 10px;
                    padding: 0 8px;
                }}
                QPushButton:hover {{
                    color: #ffffff;
                }}
            """)
            done_btn.clicked.connect(lambda checked=False, tid=task["id"]: self._on_complete(tid))
            btn_row.addWidget(done_btn)

        del_btn = QPushButton("🗑️")
        del_btn.setFixedSize(26, 24)
        del_btn.setCursor(Qt.PointingHandCursor)
        del_btn.setToolTip("Delete Task")
        del_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: 1px solid {_BORDER};
                border-radius: 4px;
                color: {_TEXT_MUTED};
                font-size: 11px;
            }}
            QPushButton:hover {{
                border-color: {_ACCENT_RED};
                color: {_ACCENT_RED};
            }}
        """)
        del_btn.clicked.connect(lambda checked=False, tid=task["id"]: self._on_delete(tid))
        btn_row.addWidget(del_btn)

        btn_row.addStretch()
        layout.addLayout(btn_row)

        return card

    def _on_resume_step(self, task_id: str, step_text: str):
        prompt = f"Continue agent task [{task_id}]: {step_text}"
        self.resume_task_requested.emit(task_id, prompt)
        self.accept()

    def _on_complete(self, task_id: str):
        db.complete_agent_task(task_id)
        self._load_tasks()

    def _on_delete(self, task_id: str):
        db.delete_agent_task(task_id)
        self._load_tasks()

    def _clear_completed(self):
        tasks = db.get_all_agent_tasks(limit=100)
        for t in tasks:
            if t["status"] == "completed":
                db.delete_agent_task(t["id"])
        self._load_tasks()

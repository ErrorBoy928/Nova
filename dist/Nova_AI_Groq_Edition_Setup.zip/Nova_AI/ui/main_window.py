"""
ui/main_window.py

Full OLED Dark Obsidian AI Desktop Assistant UI & Interactive Coding Suite.
Features:
- Pure Pitch Black Obsidian Theme (#09090b / #111116) with sleek borders.
- Interactive Code Blocks with Language Badges, 1-Click Run Code (Python/Shell/JS),
  1-Click Copy Code, 1-Click Save to File, and Embedded Console Output.
- Real-time Token Streaming (<300ms latency) for lightning-fast responsiveness.
- 1-Click Gemini API Key Dialog with Live Verification & Multi-Model Auto-Fallback.
- Autonomous Computer Control & Coding Engine.
- Live Screen Observing and Multimodal Vision.
- Bilingual natural Urdu and English speech output and recognition.
"""

from __future__ import annotations

import html as html_lib
import re
from pathlib import Path

from PySide6.QtCore import QPoint, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QAction, QClipboard, QIcon, QKeyEvent
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QScrollArea,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ai.image_gen import generate_image
from ai.llm_manager import ChatMessage, LLMError, LLMManager, clean_repetitive_patterns
from automation import executor as automation_executor
from automation.screen_observer import screen_observer, get_open_windows
from config.settings_schema import AppConfig, get_api_key, save_config
import memory.database as db
from ui.api_key_dialog import ApiKeyDialog
from ui.tasks_dialog import TasksDialog
from utils import remote_sync
from ui.icons import (
    create_attach_icon,
    create_clean_icon,
    create_copy_icon,
    create_gear_icon,
    create_health_icon,
    create_mic_icon,
    create_moon_icon,
    create_music_icon,
    create_screen_icon,
    create_send_icon,
    create_snip_icon,
    create_speaker_icon,
    create_work_icon,
)
from ui.settings_window import SettingsWindow
from ui.snipping_widget import SnippingWidget
from utils.global_hotkey import GlobalHotkeyThread
from utils.logger import get_logger
from voice.stt import ContinuousVoiceWorker, SingleShotVoiceWorker
from voice.tts import clean_text_for_speech, is_urdu_text, tts

log = get_logger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parent.parent

IMAGE_TAG_RE = re.compile(r"\[Image:\s*(.*?)\]")
_CODE_FENCE_RE = re.compile(r"```(\w*)\n?(.*?)```", re.DOTALL)

# Elite Modern Dark Obsidian Palette
_BG_BLACK = "#09090b"       # Deep modern obsidian slate (Zinc 950)
_BG_PANEL = "#111116"       # Header & input bar surface
_BG_CARD = "#14141b"        # Elevated assistant card
_BG_USER = "#1a1a24"        # User message card
_BORDER = "#22222b"         # Hairline crisp border
_BORDER_LIGHT = "#2f2f3c"   # Border hover
_BORDER_FOCUS = "#38bdf8"   # Electric cyan border highlight
_ACCENT_BLUE = "#2563eb"    # Primary blue
_ACCENT_CYAN = "#38bdf8"    # Accent cyan
_ACCENT_GREEN = "#10b981"   # Emerald status
_ACCENT_RED = "#ef4444"     # Ruby alert
_TEXT_MAIN = "#f8fafc"      # Primary text
_TEXT_MUTED = "#94a3b8"     # Secondary text
_TEXT_SUBTLE = "#64748b"    # Tertiary text


def _render_prose(text: str) -> str:
    escaped = html_lib.escape(text.strip())
    escaped = escaped.replace("\n", "<br>")
    escaped = re.sub(r"\*\*(.+?)\*\*", r'<b style="color:#ffffff;">\1</b>', escaped)
    escaped = re.sub(r"`([^`]+)`", r'<code style="background:#1b1b26;color:#38bdf8;padding:1px 4px;border-radius:3px;font-family:Consolas,monospace;">\1</code>', escaped)
    return f'<p style="margin:2px 0;line-height:1.5;">{escaped}</p>'


def _render_message_html(content: str) -> str:
    pieces: list[str] = []
    last_end = 0
    for m in _CODE_FENCE_RE.finditer(content):
        before = content[last_end:m.start()]
        if before.strip():
            pieces.append(_render_prose(before))
        lang = (m.group(1) or "code").strip()
        code = html_lib.escape(m.group(2).rstrip("\n"))
        pieces.append(
            '<div style="margin:8px 0;border-radius:6px;overflow:hidden;border:1px solid #272733;">'
            f'<div style="background:#13131a;color:#38bdf8;font-size:10px;font-weight:700;'
            'padding:4px 10px;letter-spacing:0.5px;font-family:Consolas,monospace;border-bottom:1px solid #22222d;">'
            f'{lang.upper()}</div>'
            '<pre style="background:#07070a;color:#e2e8f0;padding:10px 12px;margin:0;'
            'font-family:Consolas,monospace;font-size:12px;line-height:1.5;'
            f'white-space:pre-wrap;">{code}</pre></div>'
        )
        last_end = m.end()
    tail = content[last_end:]
    if tail.strip():
        pieces.append(_render_prose(tail))
    return "".join(pieces) if pieces else _render_prose(content)


def _render_images(html_content: str) -> str:
    def replace_tag(match):
        path_str = match.group(1).strip()
        path = Path(path_str)
        if path.exists():
            return f'<div style="margin:6px 0;"><img src="{path.resolve().as_uri()}" style="border-radius:6px;border:1px solid #2d2d38;max-width:320px;" width="320"></div>'
        return f"[Image: {path_str}]"
    return IMAGE_TAG_RE.sub(replace_tag, html_content)


SYSTEM_PROMPT_TEMPLATE = """
You are {name}, an Elite Senior Full-Stack Software Engineer, Principal Architect, and Autonomous Windows Desktop Assistant (JARVIS-grade).
You serve the user directly, decisively, and respectfully without unnecessary conversation or delay.

CODING EXPERTISE & STANDARDS:
- Mastery in Python, JavaScript, TypeScript, HTML/CSS, React, Vue, Node.js, C, C++, C#, Java, Go, Rust, SQL, Bash, PowerShell.
- Provide clean, production-ready, well-commented code. NEVER write incomplete code or placeholders like '// todo' or '...rest of code...'.
- Always wrap code in markdown code blocks with the exact language identifier (e.g. ```python, ```javascript, ```powershell, ```html, ```sql, ```cpp).
- For Python, write runnable, self-contained code that can execute directly with the user's built-in "Run Code" button.
- If diagnosing bugs or errors, identify the root cause in 1-2 concise sentences and provide the fully corrected code.

LANGUAGE BEHAVIOR & COHERENCE (CRITICAL):
- You are fully fluent in English and natural Pakistani Urdu (اردو) and Roman Urdu.
- Always reply in the exact language or mix used by the user.
- NEVER repeat words, phrases, or syllables in loops (e.g. NEVER output "کیا کیا کیا کیا" or "میں میں میں").
- Always speak in full, coherent, well-structured sentences.
- In Urdu: Speak naturally and politely (e.g. "جی سر، میں نے کوڈ لکھ دیا ہے اور ٹیسٹ کے لیے تیار ہے۔", "جی سر، کام شروع کر دیا ہے۔").
- In Roman Urdu: Speak naturally (e.g. "Ji sir, main aapki files review karne ke liye tayyar hoon.").
- In English: Speak like an advanced assistant ("Right away, sir.", "Here is the production-ready code, sir.", "Executing now, sir.").

SCREEN CONTROL & VISION PROTOCOL (CRITICAL):
1. NEVER open or flash black PowerShell or CMD console windows to perform GUI, app, or web tasks.
2. Check your current screen state context: [Screen Vision: ON] or [Screen Vision: OFF].
3. If [Screen Vision: OFF] and the user asks you to interact with an application, website, button, form, or do work on their screen:
   - DO NOT run blind command-line or PowerShell scripts.
   - Politely ask the user to turn on Screen Share / Screen Vision (or click the '👁️ Turn On Screen Vision' button) so you can see their screen and handle it directly.
   - Always include the tag [action:enable_vision] in your response.
4. If [Screen Vision: ON]:
   - You have real-time visual observation of the user's desktop.
   - Inspect the attached screen image carefully and perform visual computer operations:
     * [action:focus_app:<window_name>] — Brings target window to foreground
     * [action:click_at:<x%,y%>] — Clicks on screen percentage coordinates (e.g. 50,50 for center)
     * [action:click_and_type:<x%,y%>,<text>] — Clicks target input element and types text
     * [action:type_text:<text>] — Types text directly into focused field
     * [action:hotkey:<keys>] — Executes keyboard shortcuts (e.g. ctrl+t, enter, win+r, alt+f4)
     * [action:open_app:<name>] — Opens applications cleanly

AUTONOMOUS AGENT TASK & GOAL SAVING:
When given any multi-step, complex, or large task (e.g. building an application, creating scripts, multi-step desktop workflows, organizing files):
- Automatically save the goal and break it down into clear milestones using:
  [action:save_task:<Task Title>:<Step 1>|<Step 2>|<Step 3>...]
- As steps progress, update them with:
  [action:update_task:<task_id_or_title>:<step_index>]
- The user can view, track, and execute steps anytime via the '📋 Tasks' button in the header.
- To check existing tasks: [action:list_tasks]

AVAILABLE COMPUTER & CODING ACTIONS:
Embed one or more [action:NAME:ARG] tags when needed:
- [action:enable_vision] — Activates Screen Vision and captures current screen
- [action:save_task:<title>:<step1|step2|...>] — Saves structured multi-step agent task
- [action:update_task:<task_id>:<step_num>] — Updates agent task progress
- [action:list_tasks] — Lists all saved agent tasks
- [action:click_at:<x%,y%>] — Clicks at screen coordinates (0-100%)
- [action:click_and_type:<x%,y%>,<text>] — Clicks and types text
- [action:type_text:<text>] — Types text into focused window
- [action:hotkey:<keys>] — Presses shortcut (e.g. ctrl+c, alt+tab, win+d, enter)
- [action:focus_app:<name>] — Brings open app to foreground
- [action:open_app:<name>] — Opens any application or setting (code, notepad, chrome, calc, cmd, powershell, settings)
- [action:close_app:<name>] — Closes an app process or window
- [action:kill_process:<name_or_pid>] — Forcibly terminates program
- [action:run_code:<lang>:<code_snippet>] — Executes Python, PowerShell, Node, or Batch code silently
- [action:save_code_file:<filepath>:<content>] — Saves code directly to a file (defaults to Desktop if relative)
- [action:run_cmd:<command>] — Executes shell command silently without flashing windows
- [action:run_git:<git_args>] — Runs git command (e.g. status, diff, commit -m "msg", log)
- [action:pip_install:<package>] — Installs python package via pip
- [action:routine:<work|relax|clean|status|night>] — Smart routines
- [action:close_window] — Closes current window (Alt+F4)
- [action:snap_window:<left|right|up|down>] — Snaps window
- [action:open_folder:<path>] — Opens project folder in Windows Explorer
- [action:create_file:<filepath:content>] — Creates/writes a file
- [action:append_file:<filepath:content>] — Appends to file
- [action:create_folder:<dirname>] — Creates a folder
- [action:read_file:<filepath>] — Reads text file content
- [action:delete:<path>] — Deletes a file or directory
- [action:zip:<path>] / [action:unzip:<path>]
- [action:list_dir:<path>] — Lists directory contents
- [action:search_files:<query,drive>] — Searches files on E: or C:
- [action:set_volume:<0-100|up|down|mute>] — Controls volume
- [action:set_brightness:<0-100|up|down>] — Controls screen brightness
- [action:media:<play|pause|next|prev|stop>] — Controls media
- [action:clipboard_copy:<text>] / [action:clipboard_read]
- [action:calc:<math_expression>] — Instant offline math
- [action:screenshot] — Takes a desktop screenshot
- [action:empty_recycle_bin] / [action:clear_temp]
- [action:system_stats] — CPU, RAM, and Disk space for C: and E:
- [action:battery] / [action:wifi] / [action:network_info]
- [action:open_url:<url>] / [action:google_search:<query>] / [action:youtube_search:<query>]
- [action:generate_image:<prompt>] — Generates AI image

RULES:
1. Always include the exact [action:...] tag when the user asks you to perform an action.
2. Reply concisely. Never refuse a coding or computer task.
"""


class _CodeRunnerWorker(QThread):
    finished_run = Signal(bool, str)

    def __init__(self, lang: str, code: str):
        super().__init__()
        self.lang = lang
        self.code = code

    def run(self):
        from automation.actions import run_code
        ok, msg = run_code(f"{self.lang}:{self.code}")
        self.finished_run.emit(ok, msg)


class CodeBlockWidget(QFrame):
    """Interactive Code Block card featuring 1-click Run, Copy, Save, and Live Console Output."""

    def __init__(self, lang: str, code: str):
        super().__init__()
        self.lang = (lang or "code").lower()
        self.code = code
        self._runner_worker: _CodeRunnerWorker | None = None
        self._build_ui()

    def _build_ui(self):
        self.setStyleSheet(f"""
            QFrame {{
                background-color: #07070a;
                border: 1px solid {_BORDER};
                border-radius: 8px;
            }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header bar
        header = QFrame()
        header.setStyleSheet(f"""
            QFrame {{
                background-color: #101017;
                border-bottom: 1px solid {_BORDER};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            }}
        """)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(10, 5, 10, 5)
        h_layout.setSpacing(8)

        lang_lbl = QLabel(self.lang.upper())
        lang_lbl.setStyleSheet(f"color: {_ACCENT_CYAN}; font-size: 10px; font-weight: 800; font-family: Consolas, monospace; letter-spacing: 0.8px;")
        h_layout.addWidget(lang_lbl)

        h_layout.addStretch()

        # Run button (for runnable scripts)
        can_run = self.lang in ("python", "py", "powershell", "ps", "ps1", "cmd", "bat", "batch", "node", "js", "javascript")
        if can_run:
            self.run_btn = QPushButton("▶ Run")
            self.run_btn.setFixedHeight(22)
            self.run_btn.setCursor(Qt.PointingHandCursor)
            self.run_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #022c22;
                    color: #6ee7b7;
                    border: 1px solid #065f46;
                    border-radius: 4px;
                    font-size: 10px;
                    font-weight: 700;
                    padding: 0 8px;
                }}
                QPushButton:hover {{
                    background-color: #047857;
                    color: #ffffff;
                }}
            """)
            self.run_btn.clicked.connect(self._on_run_clicked)
            h_layout.addWidget(self.run_btn)

        # Save button
        save_btn = QPushButton("💾 Save")
        save_btn.setFixedHeight(22)
        save_btn.setCursor(Qt.PointingHandCursor)
        save_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: #15151f;
                color: {_TEXT_MUTED};
                border: 1px solid {_BORDER};
                border-radius: 4px;
                font-size: 10px;
                font-weight: 600;
                padding: 0 8px;
            }}
            QPushButton:hover {{
                color: #ffffff;
                border-color: {_BORDER_LIGHT};
                background-color: #1e1e2c;
            }}
        """)
        save_btn.clicked.connect(self._on_save_clicked)
        h_layout.addWidget(save_btn)

        # Copy button
        self.copy_btn = QPushButton("📋 Copy")
        self.copy_btn.setFixedHeight(22)
        self.copy_btn.setCursor(Qt.PointingHandCursor)
        self.copy_btn.setStyleSheet(save_btn.styleSheet())
        self.copy_btn.clicked.connect(self._on_copy_clicked)
        h_layout.addWidget(self.copy_btn)

        layout.addWidget(header)

        # Code display
        code_edit = QTextEdit()
        code_edit.setPlainText(self.code)
        code_edit.setReadOnly(True)
        line_count = len(self.code.splitlines())
        calc_height = min(max(line_count * 18 + 14, 45), 320)
        code_edit.setFixedHeight(calc_height)
        code_edit.setStyleSheet(f"""
            QTextEdit {{
                background-color: #07070a;
                border: none;
                color: #e2e8f0;
                font-family: Consolas, 'Fira Code', monospace;
                font-size: 12px;
                line-height: 1.45;
                padding: 8px 10px;
            }}
        """)
        layout.addWidget(code_edit)

        # Output console area (hidden initially)
        self.console_frame = QFrame()
        self.console_frame.setVisible(False)
        self.console_frame.setStyleSheet(f"""
            QFrame {{
                background-color: #020204;
                border-top: 1px solid {_BORDER};
                border-bottom-left-radius: 8px;
                border-bottom-right-radius: 8px;
            }}
        """)
        cons_layout = QVBoxLayout(self.console_frame)
        cons_layout.setContentsMargins(10, 8, 10, 8)
        cons_layout.setSpacing(4)

        cons_title = QLabel("CONSOLE OUTPUT:")
        cons_title.setStyleSheet("color: #64748b; font-size: 9px; font-weight: 800; font-family: Consolas, monospace;")
        cons_layout.addWidget(cons_title)

        self.console_out = QLabel("")
        self.console_out.setWordWrap(True)
        self.console_out.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.console_out.setStyleSheet("color: #10b981; font-size: 11px; font-family: Consolas, monospace;")
        cons_layout.addWidget(self.console_out)

        layout.addWidget(self.console_frame)

    def _on_copy_clicked(self):
        QApplication.clipboard().setText(self.code, QClipboard.Clipboard)
        self.copy_btn.setText("✓ Copied!")
        QTimer.singleShot(1500, lambda: self.copy_btn.setText("📋 Copy"))

    def _on_save_clicked(self):
        ext_map = {
            "python": "py", "py": "py", "javascript": "js", "js": "js",
            "html": "html", "css": "css", "powershell": "ps1", "ps1": "ps1",
            "bash": "sh", "sh": "sh", "sql": "sql", "json": "json",
            "c": "c", "cpp": "cpp", "c++": "cpp", "csharp": "cs", "cs": "cs"
        }
        ext = ext_map.get(self.lang, "txt")
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Code Snippet", f"script.{ext}", f"Source File (*.{ext});;All Files (*.*)"
        )
        if file_path:
            try:
                Path(file_path).write_text(self.code, encoding="utf-8")
                self.console_frame.setVisible(True)
                self.console_out.setText(f"[✓] Saved to: {file_path}")
                self.console_out.setStyleSheet("color: #10b981; font-size: 11px; font-family: Consolas, monospace;")
            except Exception as e:
                self.console_frame.setVisible(True)
                self.console_out.setText(f"[✕] Save error: {e}")
                self.console_out.setStyleSheet("color: #ef4444; font-size: 11px; font-family: Consolas, monospace;")

    def _on_run_clicked(self):
        self.run_btn.setEnabled(False)
        self.run_btn.setText("Running...")
        self.console_frame.setVisible(True)
        self.console_out.setText("Executing code in background...")
        self.console_out.setStyleSheet("color: #38bdf8; font-size: 11px; font-family: Consolas, monospace;")

        self._runner_worker = _CodeRunnerWorker(self.lang, self.code)
        self._runner_worker.finished_run.connect(self._on_run_completed)
        self._runner_worker.start()

    def _on_run_completed(self, success: bool, output: str):
        self.run_btn.setEnabled(True)
        self.run_btn.setText("▶ Run")
        color = "#10b981" if success else "#ef4444"
        self.console_out.setStyleSheet(f"color: {color}; font-size: 11px; font-family: Consolas, monospace;")
        self.console_out.setText(output)


class _LLMWorker(QThread):
    chunk_received = Signal(str)
    reply_ready = Signal(str)
    failed = Signal(str)

    def __init__(self, manager: LLMManager, history: list[ChatMessage], system_prompt: str):
        super().__init__()
        self.manager = manager
        self.history = history
        self.system_prompt = system_prompt

    def run(self):
        try:
            chunks = []
            for chunk in self.manager.chat_stream(self.history, system_prompt=self.system_prompt):
                chunks.append(chunk)
                self.chunk_received.emit(chunk)
            full_reply = "".join(chunks)
            self.reply_ready.emit(full_reply)
        except LLMError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:
            self.failed.emit(f"Error: {exc}")


class BackgroundTaskWorker(QThread):
    progress = Signal(str)
    finished_report = Signal(list)  # list of tuples (success: bool, act_name: str, msg: str)

    def __init__(self, actions_list: list[tuple[str, str]]):
        super().__init__()
        self.actions_list = actions_list

    def run(self):
        results = []
        for act_name, act_arg in self.actions_list:
            self.progress.emit(f"Running {act_name}...")
            if act_name == "generate_image":
                try:
                    img_path = generate_image(act_arg)
                    results.append((True, act_name, f"Image generated: {img_path}"))
                except Exception as e:
                    results.append((False, act_name, f"Image error: {e}"))
            else:
                success, msg = automation_executor.run_action(act_name, act_arg)
                results.append((success, act_name, msg))
        self.finished_report.emit(results)


class _MessageBubble(QWidget):
    """Refined message card with live streaming, interactive code blocks, and screen vision action CTA."""

    def __init__(self, role: str, content: str = "", on_speak_clicked=None, on_enable_vision_clicked=None):
        super().__init__()
        self.role = role
        self.content = content
        self.on_speak_clicked = on_speak_clicked
        self.on_enable_vision_clicked = on_enable_vision_clicked
        self.is_user = (role == "user")
        self.vision_cta_btn: QPushButton | None = None

        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(6, 3, 6, 3)

        self.card = QFrame()
        self.card_layout = QVBoxLayout(self.card)
        self.card_layout.setContentsMargins(12, 10, 12, 10)
        self.card_layout.setSpacing(6)

        if self.is_user:
            self.card.setStyleSheet(f"""
                QFrame {{
                    background-color: {_BG_USER};
                    color: {_TEXT_MAIN};
                    border-radius: 10px;
                    border: 1px solid #2b2b38;
                }}
            """)
        else:
            self.card.setStyleSheet(f"""
                QFrame {{
                    background-color: {_BG_CARD};
                    color: {_TEXT_MAIN};
                    border-radius: 10px;
                    border: 1px solid {_BORDER};
                }}
            """)

        # Assistant Header
        if not self.is_user:
            header_row = QHBoxLayout()
            header_row.setContentsMargins(0, 0, 0, 2)
            header_row.setSpacing(6)

            dot = QLabel("●")
            dot.setStyleSheet("color: #38bdf8; font-size: 8px;")
            header_row.addWidget(dot)

            name_lbl = QLabel("NOVA")
            name_lbl.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: 800; letter-spacing: 0.8px;")
            header_row.addWidget(name_lbl)

            header_row.addStretch()
            self.card_layout.addLayout(header_row)

        # Dynamic content container
        self.content_widget = QWidget()
        self.content_widget.setStyleSheet("background: transparent;")
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(6)
        self.card_layout.addWidget(self.content_widget)

        # Single streaming label for live token rendering
        self.stream_label = QLabel()
        self.stream_label.setTextFormat(Qt.RichText)
        self.stream_label.setWordWrap(True)
        self.stream_label.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
        self.stream_label.setStyleSheet("background: transparent; border: none; font-size: 13px; line-height: 1.45;")
        self.content_layout.addWidget(self.stream_label)

        # Bottom action bar for Assistant
        if not self.is_user:
            self.action_bar = QHBoxLayout()
            self.action_bar.setContentsMargins(0, 4, 0, 0)
            self.action_bar.setSpacing(6)

            self.full_copy_btn = QPushButton("Copy All")
            self.full_copy_btn.setIcon(create_copy_icon("#94a3b8", size=12))
            self.full_copy_btn.setFixedSize(76, 22)
            self.full_copy_btn.setCursor(Qt.PointingHandCursor)
            self.full_copy_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #171720;
                    color: {_TEXT_MUTED};
                    border: 1px solid #262633;
                    border-radius: 4px;
                    font-size: 10px;
                    font-weight: 600;
                    padding: 0 6px;
                }}
                QPushButton:hover {{
                    color: #ffffff;
                    border-color: #3f3f50;
                    background-color: #20202c;
                }}
            """)
            self.full_copy_btn.clicked.connect(self._copy_full_content)
            self.action_bar.addWidget(self.full_copy_btn)

            if on_speak_clicked:
                self.listen_btn = QPushButton("Speak")
                self.listen_btn.setIcon(create_speaker_icon("#94a3b8", size=12))
                self.listen_btn.setFixedSize(66, 22)
                self.listen_btn.setCursor(Qt.PointingHandCursor)
                self.listen_btn.setStyleSheet(self.full_copy_btn.styleSheet())
                self.listen_btn.clicked.connect(lambda: on_speak_clicked(self.content))
                self.action_bar.addWidget(self.listen_btn)

            self.action_bar.addStretch()
            self.card_layout.addLayout(self.action_bar)

        if self.is_user:
            self.layout.addStretch()
            self.layout.addWidget(self.card, 0)
        else:
            self.layout.addWidget(self.card, 0)
            self.layout.addStretch()

        if content:
            self.finalize_content(content)

    def update_stream_text(self, text: str):
        """Called dynamically as tokens arrive in real-time."""
        self.content = text
        self.stream_label.setText(_render_images(_render_prose(text)))

    def finalize_content(self, text: str):
        """Parses finished text into prose sections and interactive CodeBlockWidgets."""
        self.content = text
        if self.is_user:
            self.stream_label.setText(_render_images(_render_message_html(text)))
            return

        # Clear content layout
        while self.content_layout.count() > 0:
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Parse markdown code fences
        last_end = 0
        has_code_block = False
        for m in _CODE_FENCE_RE.finditer(text):
            has_code_block = True
            before = text[last_end:m.start()].strip()
            if before:
                prose_lbl = QLabel()
                prose_lbl.setTextFormat(Qt.RichText)
                prose_lbl.setWordWrap(True)
                prose_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
                prose_lbl.setStyleSheet("background: transparent; border: none; font-size: 13px; line-height: 1.45;")
                prose_lbl.setText(_render_images(_render_prose(before)))
                self.content_layout.addWidget(prose_lbl)

            lang = (m.group(1) or "code").strip()
            code_text = m.group(2).rstrip("\n")
            code_widget = CodeBlockWidget(lang, code_text)
            self.content_layout.addWidget(code_widget)
            last_end = m.end()

        tail = text[last_end:].strip()
        if tail or not has_code_block:
            display_tail = tail if has_code_block else text
            prose_lbl = QLabel()
            prose_lbl.setTextFormat(Qt.RichText)
            prose_lbl.setWordWrap(True)
            prose_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
            prose_lbl.setStyleSheet("background: transparent; border: none; font-size: 13px; line-height: 1.45;")
            prose_lbl.setText(_render_images(_render_prose(display_tail)))
            self.content_layout.addWidget(prose_lbl)

        # 1-Click Screen Vision Call-to-Action button if vision is requested
        if not self.is_user and self.on_enable_vision_clicked and hasattr(self, "action_bar"):
            text_l = text.lower()
            needs_vision = any(k in text_l for k in [
                "screen vision", "screen share", "enable_vision", "اسکرین شیئر", "اسکرین ویژن", "اسکرین آن", "screen on"
            ])
            if needs_vision and not self.vision_cta_btn:
                self.vision_cta_btn = QPushButton("👁️ Turn On Screen Vision & Allow Control")
                self.vision_cta_btn.setFixedHeight(24)
                self.vision_cta_btn.setCursor(Qt.PointingHandCursor)
                self.vision_cta_btn.setStyleSheet(f"""
                    QPushButton {{
                        background-color: #042f2e;
                        color: #5eead4;
                        border: 1px solid #0d9488;
                        border-radius: 4px;
                        font-size: 10px;
                        font-weight: 700;
                        padding: 0 10px;
                    }}
                    QPushButton:hover {{
                        background-color: #0f766e;
                        color: #ffffff;
                    }}
                """)
                def _trigger_vision():
                    self.on_enable_vision_clicked()
                    if self.vision_cta_btn:
                        self.vision_cta_btn.setText("✓ Vision Activated")
                        self.vision_cta_btn.setEnabled(False)
                self.vision_cta_btn.clicked.connect(_trigger_vision)
                self.action_bar.insertWidget(0, self.vision_cta_btn)

    def _copy_full_content(self):
        QApplication.clipboard().setText(self.content, QClipboard.Clipboard)
        self.full_copy_btn.setText("✓ Copied!")
        QTimer.singleShot(1500, lambda: self.full_copy_btn.setText("Copy All"))


class MainWindow(QWidget):
    def __init__(self, config: AppConfig, llm_manager: LLMManager):
        super().__init__()
        self.config = config
        self.llm_manager = llm_manager

        self.snipper = SnippingWidget()
        self.snipper.snipped.connect(self._on_region_snipped)

        self._continuous_thread: QThread | None = None
        self._continuous_worker: ContinuousVoiceWorker | None = None
        self._hands_free_active = False
        self._single_shot_thread: QThread | None = None
        self._single_shot_worker: SingleShotVoiceWorker | None = None
        self._llm_thread: _LLMWorker | None = None
        self._task_worker: BackgroundTaskWorker | None = None
        self._attached_path: Path | None = None

        self._current_assistant_bubble: _MessageBubble | None = None
        self._stream_text: str = ""

        # Global Hotkey Thread (Ctrl+Shift+D for Snip, Ctrl+Shift+N to Toggle Nova)
        self.hotkey_thread = GlobalHotkeyThread()
        self.hotkey_thread.hotkey_triggered.connect(self.snipper.start_snip)
        self.hotkey_thread.summon_triggered.connect(self._toggle_window_visibility)
        self.hotkey_thread.start()

        self._setup_window()
        self._build_ui()
        self._load_history()
        self._update_tasks_btn_badge()

        # Start non-blocking Desktop-Hybrid cloud sync in background
        remote_sync.start_background_sync(self.config, delay_sec=1.2)

        # Check API key seamlessly on startup
        QTimer.singleShot(600, self._check_api_key_on_startup)

    def _check_api_key_on_startup(self):
        key = get_api_key(self.config)
        if not key or len(key) < 10 or key.startswith("AQ."):
            self._open_api_key_dialog()

    def _toggle_window_visibility(self):
        """Summons Nova to foreground or tucks it away."""
        if self.isVisible() and not self.isMinimized():
            self.hide()
        else:
            self.showNormal()
            self.raise_()
            self.activateWindow()

    def _setup_window(self):
        self.setWindowTitle(f"{self.config.ui.assistant_name} - Coding & Desktop Assistant")
        self.resize(self.config.ui.start_width, self.config.ui.start_height)
        self.setMinimumSize(420, 560)

        flags = Qt.Window
        if self.config.ui.always_on_top:
            flags |= Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setWindowOpacity(self.config.ui.window_opacity)

        # High-End Dark Obsidian Styling
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {_BG_BLACK};
                color: {_TEXT_MAIN};
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            }}
            QScrollArea {{
                background: {_BG_BLACK};
                border: none;
            }}
            QScrollBar:vertical {{
                background: transparent;
                width: 6px;
                margin: 0;
            }}
            QScrollBar::handle:vertical {{
                background: #272733;
                min-height: 28px;
                border-radius: 3px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: #3f3f50;
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0;
            }}
        """)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(8)

        # Header Row 1: App title & Action Controls
        header = QHBoxLayout()
        header.setContentsMargins(2, 2, 2, 4)
        header.setSpacing(6)

        title_box = QHBoxLayout()
        title_box.setSpacing(6)

        self.beacon_dot = QLabel("●")
        self.beacon_dot.setStyleSheet("color: #10b981; font-size: 10px;")
        title_box.addWidget(self.beacon_dot)

        self.title_label = QLabel(self.config.ui.assistant_name.upper())
        self.title_label.setStyleSheet("color: #ffffff; font-size: 15px; font-weight: 800; letter-spacing: 1.2px;")
        title_box.addWidget(self.title_label)

        self.status_pill = QLabel("READY")
        self.status_pill.setStyleSheet(f"""
            color: #38bdf8;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.6px;
            padding: 2px 8px;
            border-radius: 9px;
            background: #111118;
            border: 1px solid #272735;
        """)
        title_box.addWidget(self.status_pill)
        header.addLayout(title_box)

        header.addStretch()

        # API Key Config Button
        api_btn = QPushButton("⚡ Groq Key")
        api_btn.setToolTip("Configure Groq API Key (Llama 3.3 70B & 3.1 8B)")
        api_btn.setCursor(Qt.PointingHandCursor)
        api_btn.setFixedHeight(26)
        self._style_header_button(api_btn, active=False)
        api_btn.clicked.connect(self._open_api_key_dialog)
        header.addWidget(api_btn)

        # Autonomous Agent Tasks Dialog Button
        self.tasks_btn = QPushButton("📋 Tasks")
        self.tasks_btn.setToolTip("View & Manage Saved Agent Tasks and Goals")
        self.tasks_btn.setCursor(Qt.PointingHandCursor)
        self.tasks_btn.setFixedHeight(26)
        self._style_header_button(self.tasks_btn, active=False)
        self.tasks_btn.clicked.connect(self._open_tasks_dialog)
        header.addWidget(self.tasks_btn)

        # Screen Vision Toggle (AI sees screen)
        self.screen_vision_btn = QPushButton("Vision: OFF")
        self.screen_vision_btn.setIcon(create_screen_icon("#94a3b8", size=14))
        self.screen_vision_btn.setCursor(Qt.PointingHandCursor)
        self.screen_vision_btn.setFixedHeight(26)
        self._style_header_button(self.screen_vision_btn, active=self.config.ui.screen_observing)
        self.screen_vision_btn.clicked.connect(self._toggle_screen_vision)
        header.addWidget(self.screen_vision_btn)

        # Hands-Free Voice Mode Toggle
        self.hands_free_btn = QPushButton("Hands-Free: OFF")
        self.hands_free_btn.setIcon(create_mic_icon("#94a3b8", size=14))
        self.hands_free_btn.setCursor(Qt.PointingHandCursor)
        self.hands_free_btn.setFixedHeight(26)
        self._style_header_button(self.hands_free_btn, active=False)
        self.hands_free_btn.clicked.connect(self._toggle_hands_free_mode)
        header.addWidget(self.hands_free_btn)

        # Speech Toggle Button
        self.speak_toggle_btn = QPushButton("Speech: ON" if self.config.voice.auto_speak else "Speech: OFF")
        self.speak_toggle_btn.setIcon(create_speaker_icon("#38bdf8" if self.config.voice.auto_speak else "#94a3b8", size=14))
        self.speak_toggle_btn.setCursor(Qt.PointingHandCursor)
        self.speak_toggle_btn.setFixedHeight(26)
        self._style_header_button(self.speak_toggle_btn, active=self.config.voice.auto_speak)
        self.speak_toggle_btn.clicked.connect(self._toggle_auto_speak)
        header.addWidget(self.speak_toggle_btn)

        # Snip Button
        snip_btn = QPushButton()
        snip_btn.setIcon(create_snip_icon("#94a3b8", size=15))
        snip_btn.setToolTip("Snip Screen (Ctrl+Shift+D)")
        snip_btn.setCursor(Qt.PointingHandCursor)
        snip_btn.setFixedSize(26, 26)
        self._style_header_button(snip_btn, active=False)
        snip_btn.clicked.connect(self.snipper.start_snip)
        header.addWidget(snip_btn)

        # Settings Button
        settings_btn = QPushButton()
        settings_btn.setIcon(create_gear_icon("#94a3b8", size=15))
        settings_btn.setToolTip("Settings")
        settings_btn.setCursor(Qt.PointingHandCursor)
        settings_btn.setFixedSize(26, 26)
        self._style_header_button(settings_btn, active=False)
        settings_btn.clicked.connect(self._open_settings)
        header.addWidget(settings_btn)

        root.addLayout(header)

        # Scroll Area for Messages
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.message_container = QWidget()
        self.message_container.setStyleSheet("background: transparent;")
        self.message_layout = QVBoxLayout(self.message_container)
        self.message_layout.setContentsMargins(0, 0, 0, 0)
        self.message_layout.setSpacing(6)
        self.message_layout.addStretch()
        self.scroll.setWidget(self.message_container)
        root.addWidget(self.scroll, 1)

        # Attachment preview bar
        self.attachment_preview = QLabel()
        self.attachment_preview.setVisible(False)
        self.attachment_preview.setStyleSheet(f"""
            color: {_ACCENT_CYAN};
            font-size: 11px;
            font-weight: 600;
            background: {_BG_PANEL};
            border: 1px solid {_BORDER};
            border-radius: 6px;
            padding: 4px 10px;
        """)
        root.addWidget(self.attachment_preview)

        # Developer & Coding Quick Action Chips Row
        chips_layout = QHBoxLayout()
        chips_layout.setContentsMargins(2, 2, 2, 2)
        chips_layout.setSpacing(6)

        chips_data = [
            ("🐛 Debug & Fix", create_clean_icon("#38bdf8", size=12), "analyze this code, find all bugs or edge cases, and provide the complete fix:"),
            ("⚡ Optimize", create_work_icon("#60a5fa", size=12), "optimize and refactor this code for speed, memory, and clean architecture:"),
            ("🧪 Unit Tests", create_health_icon("#10b981", size=12), "write comprehensive unit tests with edge cases for this:"),
            ("📖 Explain Code", create_moon_icon("#a78bfa", size=12), "explain this code step-by-step with logic breakdown:"),
            ("▶️ Run Python", create_music_icon("#f472b6", size=12), "write and run a self-contained python script to "),
        ]

        for label, icon, cmd in chips_data:
            btn = QPushButton(label)
            btn.setIcon(icon)
            btn.setFixedHeight(24)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #121219;
                    color: {_TEXT_MUTED};
                    border: 1px solid {_BORDER};
                    border-radius: 12px;
                    padding: 0 10px;
                    font-size: 10px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    color: #ffffff;
                    border-color: #3f3f52;
                    background-color: #1b1b26;
                }}
            """)
            btn.clicked.connect(lambda checked=False, c=cmd: self._send_quick_prompt(c))
            chips_layout.addWidget(btn)

        chips_layout.addStretch()
        root.addLayout(chips_layout)

        # Input Card
        input_card = QFrame()
        input_card.setStyleSheet(f"""
            QFrame {{
                background-color: {_BG_PANEL};
                border: 1px solid {_BORDER};
                border-radius: 10px;
            }}
        """)
        card_layout = QVBoxLayout(input_card)
        card_layout.setContentsMargins(8, 8, 8, 8)
        card_layout.setSpacing(4)

        # Text input field
        self.input_edit = QTextEdit()
        self.input_edit.setPlaceholderText("Ask Nova, write code, run scripts, or speak… (Enter to send, Shift+Enter for newline)")
        self.input_edit.setMaximumHeight(85)
        self.input_edit.setMinimumHeight(40)
        self.input_edit.setStyleSheet(f"""
            QTextEdit {{
                background: transparent;
                border: none;
                color: {_TEXT_MAIN};
                font-size: 13px;
                padding: 4px 6px;
            }}
        """)
        self.input_edit.installEventFilter(self)
        card_layout.addWidget(self.input_edit)

        # Bottom controls row
        controls_row = QHBoxLayout()
        controls_row.setContentsMargins(2, 2, 2, 2)
        controls_row.setSpacing(6)

        # Plus / Attach button
        self.plus_btn = QPushButton()
        self.plus_btn.setIcon(create_attach_icon("#94a3b8", size=16))
        self.plus_btn.setToolTip("Attach File, Code, or Snip")
        self.plus_btn.setFixedSize(28, 28)
        self.plus_btn.setCursor(Qt.PointingHandCursor)
        self.plus_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {_BG_CARD};
                border: 1px solid {_BORDER};
                border-radius: 6px;
            }}
            QPushButton:hover {{
                border-color: {_ACCENT_CYAN};
                background-color: #1a1a24;
            }}
        """)
        self._setup_plus_menu()
        self.plus_btn.clicked.connect(self._show_plus_menu)
        controls_row.addWidget(self.plus_btn)

        # Push-To-Talk Mic Button
        self.mic_btn = QPushButton("Listen")
        self.mic_btn.setIcon(create_mic_icon("#38bdf8", size=15))
        self.mic_btn.setFixedHeight(28)
        self.mic_btn.setCursor(Qt.PointingHandCursor)
        self.mic_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: #0c1c2e;
                color: {_ACCENT_CYAN};
                border: 1px solid #1e3a8a;
                border-radius: 14px;
                padding: 0 12px;
                font-size: 11px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background-color: #1e3a8a;
                color: #ffffff;
            }}
        """)
        self.mic_btn.clicked.connect(self._on_single_shot_mic_clicked)
        controls_row.addWidget(self.mic_btn)

        controls_row.addStretch()

        # Clear button
        clear_btn = QPushButton("Clear")
        clear_btn.setFixedHeight(28)
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {_TEXT_MUTED};
                border: 1px solid {_BORDER};
                border-radius: 6px;
                padding: 0 12px;
                font-size: 11px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                color: white;
                background-color: #1b1b24;
                border-color: #3f3f50;
            }}
        """)
        clear_btn.clicked.connect(self._clear_chat)
        controls_row.addWidget(clear_btn)

        # Send button
        self.send_btn = QPushButton("Send")
        self.send_btn.setIcon(create_send_icon("#ffffff", size=14))
        self.send_btn.setFixedHeight(28)
        self.send_btn.setCursor(Qt.PointingHandCursor)
        self.send_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {_ACCENT_BLUE};
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: 700;
                padding: 0 16px;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: #1d4ed8;
            }}
        """)
        self.send_btn.clicked.connect(self._send_message)
        controls_row.addWidget(self.send_btn)

        card_layout.addLayout(controls_row)
        root.addWidget(input_card)

    def _open_api_key_dialog(self):
        dlg = ApiKeyDialog(self.config, self)
        dlg.exec()

    def _send_quick_prompt(self, text: str):
        self.input_edit.setPlainText(text)
        self.input_edit.setFocus()
        cursor = self.input_edit.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.input_edit.setTextCursor(cursor)

    def _style_header_button(self, btn: QPushButton, active: bool = False):
        if active:
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #032e22;
                    color: #6ee7b7;
                    border: 1px solid #059669;
                    border-radius: 13px;
                    padding: 0 10px;
                    font-size: 10px;
                    font-weight: 700;
                }}
                QPushButton:hover {{
                    background-color: #047857;
                }}
            """)
        else:
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: #111116;
                    color: {_TEXT_MUTED};
                    border: 1px solid {_BORDER};
                    border-radius: 13px;
                    padding: 0 10px;
                    font-size: 10px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    border-color: {_ACCENT_CYAN};
                    color: white;
                    background-color: #171720;
                }}
            """)

    def _setup_plus_menu(self):
        self.plus_menu = QMenu(self)
        self.plus_menu.setStyleSheet(f"""
            QMenu {{
                background-color: #121217;
                color: {_TEXT_MAIN};
                border: 1px solid {_BORDER};
                border-radius: 6px;
                padding: 4px;
            }}
            QMenu::item {{
                padding: 6px 16px;
                border-radius: 4px;
            }}
            QMenu::item:selected {{
                background-color: {_ACCENT_BLUE};
                color: white;
            }}
        """)
        attach_act = QAction("📎 Attach Source File or Image...", self)
        attach_act.triggered.connect(self._on_attach_file)
        self.plus_menu.addAction(attach_act)

        run_py_act = QAction("▶️ Run Python Script / File...", self)
        run_py_act.triggered.connect(self._on_run_python_file)
        self.plus_menu.addAction(run_py_act)

        snip_act = QAction("✂️ Snip Screen (Ctrl+Shift+D)", self)
        snip_act.triggered.connect(self.snipper.start_snip)
        self.plus_menu.addAction(snip_act)

        key_act = QAction("⚡ Configure Groq API Key...", self)
        key_act.triggered.connect(self._open_api_key_dialog)
        self.plus_menu.addAction(key_act)

        stats_act = QAction("💻 Check System & Disks", self)
        stats_act.triggered.connect(lambda: self._quick_action("system_stats"))
        self.plus_menu.addAction(stats_act)

    def _on_run_python_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Python Script to Run", "", "Python Files (*.py);;All Files (*.*)"
        )
        if file_path:
            p = Path(file_path)
            code = p.read_text(encoding="utf-8")
            self._add_bubble("user", f"Run python file: `{p.name}`")
            self.status_pill.setText("RUNNING SCRIPT...")
            worker = _CodeRunnerWorker("python", code)
            def on_done(ok, msg):
                self.status_pill.setText("READY")
                self._add_bubble("assistant", f"**Execution Result ({p.name}):**\n```\n{msg}\n```")
            worker.finished_run.connect(on_done)
            worker.start()

    def _show_plus_menu(self):
        pos = self.plus_btn.mapToGlobal(QPoint(0, -self.plus_menu.sizeHint().height() - 4))
        self.plus_menu.exec(pos)

    def _load_history(self):
        for msg in db.get_recent_history(limit=30):
            self._add_bubble(msg["role"], msg["content"])

    def _add_bubble(self, role: str, content: str = "") -> _MessageBubble:
        bubble = _MessageBubble(
            role,
            content,
            on_speak_clicked=self._speak_text,
            on_enable_vision_clicked=self.enable_screen_vision
        )
        self.message_layout.insertWidget(self.message_layout.count() - 1, bubble)
        self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum())
        return bubble

    def _add_action_badge(self, success: bool, message: str):
        tag = "[✓] Completed:" if success else "[✕] Notice:"
        badge = QLabel(f"{tag} {message}")
        color = _ACCENT_GREEN if success else _ACCENT_RED
        bg_color = "#03201a" if success else "#27070d"
        border_color = "#065f46" if success else "#991b1b"
        badge.setStyleSheet(f"""
            background-color: {bg_color};
            color: {color};
            border: 1px solid {border_color};
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 600;
            margin: 2px 6px;
        """)
        self.message_layout.insertWidget(self.message_layout.count() - 1, badge)
        self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum())

    def _toggle_screen_vision(self):
        """Toggles background screen observing."""
        self.config.ui.screen_observing = not self.config.ui.screen_observing
        screen_observer.set_enabled(self.config.ui.screen_observing)
        self.screen_vision_btn.setText("Vision: ON" if self.config.ui.screen_observing else "Vision: OFF")
        self.screen_vision_btn.setIcon(create_screen_icon("#6ee7b7" if self.config.ui.screen_observing else "#94a3b8", size=14))
        self._style_header_button(self.screen_vision_btn, active=self.config.ui.screen_observing)
        save_config(self.config)
        log.info("Screen vision set to {}", self.config.ui.screen_observing)

    def enable_screen_vision(self, auto_capture: bool = True):
        """Explicitly enables screen vision, updates header controls, and captures screen."""
        self.config.ui.screen_observing = True
        screen_observer.set_enabled(True)
        self.screen_vision_btn.setText("Vision: ON")
        self.screen_vision_btn.setIcon(create_screen_icon("#6ee7b7", size=14))
        self._style_header_button(self.screen_vision_btn, active=True)
        save_config(self.config)
        log.info("Screen vision set to True")
        if auto_capture:
            shot_path, win_title = screen_observer.capture_now()
            self._add_action_badge(True, f"Screen Vision is now ON. Active Window: '{win_title}'.")

    def _open_tasks_dialog(self):
        dlg = TasksDialog(self)
        dlg.resume_task_requested.connect(self._on_resume_task_requested)
        dlg.exec()
        self._update_tasks_btn_badge()

    def _on_resume_task_requested(self, task_id: str, prompt: str):
        self.input_edit.setText(prompt)
        self._send_message()

    def _update_tasks_btn_badge(self):
        try:
            active = db.get_active_agent_task()
            if active:
                tot = len(active.get("steps", []))
                cur = active.get("current_step", 0) + 1
                self.tasks_btn.setText(f"📋 Tasks ({cur}/{tot})")
                self._style_header_button(self.tasks_btn, active=True)
            else:
                self.tasks_btn.setText("📋 Tasks")
                self._style_header_button(self.tasks_btn, active=False)
        except Exception:
            self.tasks_btn.setText("📋 Tasks")
            self._style_header_button(self.tasks_btn, active=False)

    def _toggle_auto_speak(self):
        self.config.voice.auto_speak = not self.config.voice.auto_speak
        self.speak_toggle_btn.setText("Speech: ON" if self.config.voice.auto_speak else "Speech: OFF")
        self.speak_toggle_btn.setIcon(create_speaker_icon("#6ee7b7" if self.config.voice.auto_speak else "#94a3b8", size=14))
        self._style_header_button(self.speak_toggle_btn, active=self.config.voice.auto_speak)
        if not self.config.voice.auto_speak:
            tts.stop()
        save_config(self.config)

    def _toggle_hands_free_mode(self):
        """Toggles continuous hands-free voice loop in the background."""
        self._hands_free_active = not self._hands_free_active
        if self._hands_free_active:
            self.hands_free_btn.setText("Hands-Free: ON")
            self.hands_free_btn.setIcon(create_mic_icon("#6ee7b7", size=14))
            self._style_header_button(self.hands_free_btn, active=True)
            self._start_continuous_listener()
        else:
            self.hands_free_btn.setText("Hands-Free: OFF")
            self.hands_free_btn.setIcon(create_mic_icon("#94a3b8", size=14))
            self._style_header_button(self.hands_free_btn, active=False)
            self._stop_continuous_listener()

    def _start_continuous_listener(self):
        if self._continuous_thread and self._continuous_thread.isRunning():
            return

        self._continuous_thread = QThread()
        self._continuous_worker = ContinuousVoiceWorker(
            preferred_language=self.config.voice.stt_language
        )
        self._continuous_worker.moveToThread(self._continuous_thread)

        self._continuous_worker.status_changed.connect(lambda s: self.status_pill.setText(s.upper()))
        self._continuous_worker.speech_detected.connect(self._on_continuous_speech_detected)

        self._continuous_thread.started.connect(self._continuous_worker.run)
        self._continuous_thread.start()
        log.info("Continuous Hands-Free voice mode enabled.")

    def _stop_continuous_listener(self):
        if self._continuous_worker:
            self._continuous_worker.stop()
        if self._continuous_thread and self._continuous_thread.isRunning():
            self._continuous_thread.quit()
        self.status_pill.setText("READY")

    def _on_continuous_speech_detected(self, text: str):
        if not text:
            return
        if self._continuous_worker:
            self._continuous_worker.pause()

        self.input_edit.setText(text)
        self._send_message()

    def _on_single_shot_mic_clicked(self):
        """Single-shot recording when user clicks the Mic button."""
        if self._single_shot_thread and self._single_shot_thread.isRunning():
            return

        self.mic_btn.setText("Listening...")
        self.status_pill.setText("SPEAK NOW...")

        self._single_shot_thread = QThread()
        self._single_shot_worker = SingleShotVoiceWorker(
            preferred_language=self.config.voice.stt_language,
            record_seconds=5
        )
        self._single_shot_worker.moveToThread(self._single_shot_thread)

        def on_transcribed(text: str):
            self.input_edit.setText(text)
            self._send_message()

        def on_done():
            self.mic_btn.setText("Listen")
            self.status_pill.setText("READY")

        self._single_shot_worker.transcription_ready.connect(on_transcribed)
        self._single_shot_worker.error_occurred.connect(lambda err: self.status_pill.setText(err.upper()))
        self._single_shot_worker.finished.connect(on_done)

        self._single_shot_thread.started.connect(self._single_shot_worker.run)
        self._single_shot_worker.finished.connect(self._single_shot_thread.quit)
        self._single_shot_worker.finished.connect(self._single_shot_worker.deleteLater)
        self._single_shot_thread.finished.connect(self._single_shot_thread.deleteLater)
        self._single_shot_thread.start()

    def _speak_text(self, text: str):
        self.status_pill.setText("SPEAKING...")
        if self._continuous_worker and self._hands_free_active:
            self._continuous_worker.pause()

        voice = self.config.voice.tts_voice_ur if is_urdu_text(text) else self.config.voice.tts_voice_en

        def on_speech_ended():
            self.status_pill.setText("READY")
            if self._continuous_worker and self._hands_free_active:
                self._continuous_worker.resume()

        tts.speak(text, voice=voice, on_finished=on_speech_ended)

    def _on_region_snipped(self, image_path: str):
        self._attached_path = Path(image_path)
        self.attachment_preview.setText(f"[Attached: {self._attached_path.name}]")
        self.attachment_preview.setVisible(True)

    def _on_attach_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Attach File or Code", "", "Source Code & Images (*.py *.js *.html *.css *.json *.txt *.png *.jpg);;All Files (*.*)"
        )
        if file_path:
            self._attached_path = Path(file_path)
            self.attachment_preview.setText(f"[Attached: {self._attached_path.name}]")
            self.attachment_preview.setVisible(True)

    def _quick_action(self, action_name: str, arg: str = ""):
        self.input_edit.setText(f"Execute {action_name} {arg}".strip())
        self._send_message()

    def _clear_chat(self):
        while self.message_layout.count() > 1:
            item = self.message_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        db.clear_history()

    def _open_settings(self):
        dlg = SettingsWindow(self.config, self)
        dlg.exec()
        save_config(self.config)

    def _send_message(self, prefix: str = ""):
        text = self.input_edit.toPlainText().strip()
        if prefix:
            text = f"{prefix} {text}".strip()

        screen_context_path = None
        active_window_title = ""
        if self.config.ui.screen_observing and not self._attached_path:
            shot_path, win_title = screen_observer.capture_now()
            if shot_path and shot_path.exists():
                screen_context_path = shot_path
                active_window_title = win_title

        if not text and not self._attached_path and not screen_context_path:
            return

        image_path_to_send = self._attached_path or screen_context_path
        self._attached_path = None
        self.attachment_preview.setVisible(False)
        self.input_edit.clear()

        # Add User bubble
        bubble_text = text or "[Attached Screen Context]"
        if image_path_to_send:
            bubble_text = f"{bubble_text}\n[Image: {image_path_to_send}]"
        self._add_bubble("user", bubble_text)
        db.add_message("user", bubble_text)

        # Prepare Chat Messages
        history: list[ChatMessage] = []
        for msg in db.get_recent_history(limit=10):
            history.append(ChatMessage(role=msg["role"], content=msg["content"]))

        # Attach image to the latest user message for vision
        if image_path_to_send and history and history[-1].role == "user":
            history[-1].image_path = str(image_path_to_send)

        # Use latest cloud-synced system prompt (with offline built-in fallback)
        active_template = remote_sync.get_active_system_prompt(fallback=SYSTEM_PROMPT_TEMPLATE)
        system_prompt = active_template.format(name=self.config.ui.assistant_name)

        # Live Desktop Observation & Screen Vision Context
        if self.config.ui.screen_observing:
            open_wins = get_open_windows()
            wins_str = ", ".join(f"'{w}'" for w in open_wins) if open_wins else "Desktop"
            system_prompt += (
                f"\n[Screen Vision: ON]\n"
                f"- Active Foreground Window: '{active_window_title or 'Desktop'}'\n"
                f"- Open Application Windows: {wins_str}\n"
                f"- Screen observation is active and screenshot is attached. Inspect the screen and use visual desktop actions directly.\n"
            )
        else:
            system_prompt += (
                "\n[Screen Vision: OFF]\n"
                "- Screen Vision is currently OFF.\n"
                "- If the user asks you to interact with apps, websites, buttons, or perform GUI desktop tasks, DO NOT run black console PowerShell scripts! Instead, politely ask the user to turn on Screen Share / Screen Vision (or click the '👁️ Turn On Screen Vision' button) and include [action:enable_vision] in your response.\n"
            )

        active_task = db.get_active_agent_task()
        if active_task:
            steps_preview = " -> ".join(active_task.get("steps", []))
            system_prompt += (
                f"\n[Active Agent Task in Progress]\n"
                f"- Task ID: {active_task['id']}\n"
                f"- Title: {active_task['title']}\n"
                f"- Current Step: Step {active_task['current_step'] + 1} of {len(active_task.get('steps', []))}\n"
                f"- Milestone Steps: {steps_preview}\n"
            )

        facts = db.get_all_facts()
        if facts:
            system_prompt += "\nUser Facts:\n" + "\n".join(f"- {f}" for f in facts)

        self.send_btn.setEnabled(False)
        self.status_pill.setText("STREAMING...")

        # Create Assistant Bubble for live streaming output
        self._current_assistant_bubble = self._add_bubble("assistant", "")
        self._stream_text = ""

        self._llm_thread = _LLMWorker(self.llm_manager, history, system_prompt)
        self._llm_thread.chunk_received.connect(self._on_llm_chunk)
        self._llm_thread.reply_ready.connect(self._on_llm_replied)
        self._llm_thread.failed.connect(self._on_llm_failed)
        self._llm_thread.start()

    def _on_llm_chunk(self, chunk: str):
        self._stream_text += chunk
        if self._current_assistant_bubble:
            # Strip incomplete action tags from live preview
            clean_display = re.sub(r"\[action:[^\]]*\]?", "", self._stream_text, flags=re.IGNORECASE)
            self._current_assistant_bubble.update_stream_text(clean_display)
            self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum())

    def _on_llm_replied(self, full_reply: str):
        self.send_btn.setEnabled(True)
        full_reply = clean_repetitive_patterns(full_reply)
        clean_text, actions_list = automation_executor.extract_actions(full_reply)
        clean_text = clean_repetitive_patterns(clean_text)

        if self._current_assistant_bubble:
            self._current_assistant_bubble.finalize_content(clean_text or "(Task acknowledged)")
        else:
            self._add_bubble("assistant", clean_text or "(Task acknowledged)")

        if clean_text:
            db.add_message("assistant", clean_text)

        if not actions_list:
            self.status_pill.setText("READY")
            if self.config.voice.auto_speak and clean_text:
                self._speak_text(clean_text)
            elif self._continuous_worker and self._hands_free_active:
                self._continuous_worker.resume()
            return

        if self.config.voice.auto_speak and clean_text:
            self._speak_text(clean_text)

        # Run tasks in background thread
        self.status_pill.setText("EXECUTING...")
        self._task_worker = BackgroundTaskWorker(actions_list)
        self._task_worker.progress.connect(lambda s: self.status_pill.setText(s.upper()))
        self._task_worker.finished_report.connect(self._on_background_tasks_completed)
        self._task_worker.start()

    def _on_background_tasks_completed(self, results: list[tuple[bool, str, str]]):
        for success, act_name, msg in results:
            self._add_action_badge(success, msg)
            if act_name in ("enable_vision", "screen_vision", "start_vision") and success:
                self.enable_screen_vision(auto_capture=False)
            if act_name in ("save_task", "update_task", "complete_task", "plan_task"):
                self._update_tasks_btn_badge()

        is_ur = any(is_urdu_text(r[2]) for r in results) or is_urdu_text(self.config.voice.stt_language)
        reports = [r[2] for r in results if r[2]]
        summary = " | ".join(reports) if reports else "Action finished."
        all_ok = all(r[0] for r in results)

        name_tag = self.config.ui.assistant_name.upper()
        if is_ur:
            spoken_report = f"سر، کام مکمل ہو گیا ہے۔ {summary}" if all_ok else f"سر، رپورٹ: {summary}"
            bubble_report = f"**{name_tag} رپورٹ:**\n{summary}"
        else:
            spoken_report = f"Task completed, sir. {summary}" if all_ok else f"Task notice: {summary}"
            bubble_report = f"**{name_tag} Report:**\n{summary}"

        self._add_bubble("assistant", bubble_report)
        db.add_message("assistant", bubble_report)

        self.status_pill.setText("READY")

        if self.config.voice.auto_speak:
            self._speak_text(spoken_report)
        elif self._continuous_worker and self._hands_free_active:
            self._continuous_worker.resume()

    def _on_llm_failed(self, error: str):
        self.send_btn.setEnabled(True)
        self.status_pill.setText("ERROR")
        err_msg = f"[Error] {error}"
        if self._current_assistant_bubble:
            self._current_assistant_bubble.finalize_content(err_msg)
        else:
            self._add_bubble("assistant", err_msg)

        if self._continuous_worker and self._hands_free_active:
            self._continuous_worker.resume()

        # Prompt API key dialog if key is missing or unauthorized
        err_lower = error.lower()
        if any(x in err_lower for x in ["api key", "groq", "unauthenticated", "invalid api key", "permission_denied", "401"]):
            QTimer.singleShot(500, self._open_api_key_dialog)

    def eventFilter(self, obj, event):
        if obj is self.input_edit and event.type() == QKeyEvent.KeyPress:
            if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not (event.modifiers() & Qt.ShiftModifier):
                self._send_message()
                return True
        return super().eventFilter(obj, event)

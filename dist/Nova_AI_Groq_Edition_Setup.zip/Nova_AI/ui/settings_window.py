"""
ui/settings_window.py

Settings dialog for configuring AI providers, API keys, voice engines, and preferences.
Full OLED Pitch Black theme.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

from config.settings_schema import AppConfig, save_config
from utils.logger import get_logger

log = get_logger(__name__)

PROVIDERS = ["gemini", "openai", "anthropic", "ollama", "lmstudio"]
ENGLISH_VOICES = [
    ("en-US-AriaNeural (Natural Female)", "en-US-AriaNeural"),
    ("en-US-GuyNeural (Natural Male)", "en-US-GuyNeural"),
    ("en-US-JennyNeural (Warm Female)", "en-US-JennyNeural"),
]
URDU_VOICES = [
    ("ur-PK-UzmaNeural (Pakistani Urdu Female - Natural)", "ur-PK-UzmaNeural"),
    ("ur-PK-AsadNeural (Pakistani Urdu Male - Natural)", "ur-PK-AsadNeural"),
]


class SettingsWindow(QDialog):
    def __init__(self, config: AppConfig, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("System Settings")
        self.resize(460, 520)
        self._apply_theme()
        self._build_ui()

    def _apply_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #09090b;
                color: #f8fafc;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            }
            QLabel {
                color: #cbd5e1;
                font-size: 12px;
                font-weight: 500;
            }
            QLineEdit, QComboBox {
                background-color: #121217;
                color: #f8fafc;
                border: 1px solid #272733;
                border-radius: 6px;
                padding: 7px 12px;
                font-size: 12px;
            }
            QLineEdit:focus, QComboBox:focus {
                border-color: #38bdf8;
                background-color: #16161d;
            }
            QCheckBox {
                color: #e2e8f0;
                font-size: 12px;
                spacing: 8px;
            }
            QPushButton {
                background-color: #2563eb;
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: 700;
                padding: 8px 18px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
        """)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 20, 20, 20)
        root.setSpacing(14)

        title = QLabel("SYSTEM SETTINGS")
        title.setStyleSheet("font-size: 15px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px;")
        root.addWidget(title)

        form = QFormLayout()
        form.setSpacing(10)

        # Provider
        self.provider_combo = QComboBox()
        self.provider_combo.addItems(PROVIDERS)
        self.provider_combo.setCurrentText(self.config.llm.provider)
        form.addRow("AI Provider:", self.provider_combo)

        # Model
        self.model_input = QLineEdit(self.config.llm.model)
        form.addRow("Model Name:", self.model_input)

        # Gemini API Key
        self.api_key_input = QLineEdit(self.config.llm.api_key)
        self.api_key_input.setEchoMode(QLineEdit.Password)
        self.api_key_input.setPlaceholderText("Enter Google Gemini API Key")
        form.addRow("API Key:", self.api_key_input)

        # Assistant Name
        self.name_input = QLineEdit(self.config.ui.assistant_name)
        form.addRow("Assistant Name:", self.name_input)

        # Voice Auto-Speak
        self.auto_speak_chk = QCheckBox("Automatically read replies aloud")
        self.auto_speak_chk.setChecked(self.config.voice.auto_speak)
        form.addRow("Voice Output:", self.auto_speak_chk)

        # English Voice
        self.voice_en_combo = QComboBox()
        for label, val in ENGLISH_VOICES:
            self.voice_en_combo.addItem(label, val)
            if val == self.config.voice.tts_voice_en:
                self.voice_en_combo.setCurrentText(label)
        form.addRow("English Voice:", self.voice_en_combo)

        # Urdu Voice
        self.voice_ur_combo = QComboBox()
        for label, val in URDU_VOICES:
            self.voice_ur_combo.addItem(label, val)
            if val == self.config.voice.tts_voice_ur:
                self.voice_ur_combo.setCurrentText(label)
        form.addRow("Urdu Voice:", self.voice_ur_combo)

        # STT Language
        self.stt_lang_combo = QComboBox()
        self.stt_lang_combo.addItem("Auto-Detect (English / Urdu)", "auto")
        self.stt_lang_combo.addItem("Urdu (اردو)", "ur")
        self.stt_lang_combo.addItem("English", "en")
        idx = self.stt_lang_combo.findData(self.config.voice.stt_language)
        if idx >= 0:
            self.stt_lang_combo.setCurrentIndex(idx)
        form.addRow("Voice Input Language:", self.stt_lang_combo)

        # Always on top
        self.on_top_chk = QCheckBox("Keep window always on top")
        self.on_top_chk.setChecked(self.config.ui.always_on_top)
        form.addRow("Window:", self.on_top_chk)

        root.addLayout(form)
        root.addStretch()

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet("background-color: #1a1a1a; color: #94a3b8;")
        cancel_btn.clicked.connect(self.reject)

        save_btn = QPushButton("Save & Apply")
        save_btn.clicked.connect(self._save)

        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        root.addLayout(btn_row)

    def _save(self):
        self.config.llm.provider = self.provider_combo.currentText()
        self.config.llm.model = self.model_input.text().strip() or "gemini-3.5-flash-lite"
        self.config.llm.api_key = self.api_key_input.text().strip()
        self.config.ui.assistant_name = self.name_input.text().strip() or "Nova"
        self.config.voice.auto_speak = self.auto_speak_chk.isChecked()
        self.config.voice.tts_voice_en = self.voice_en_combo.currentData() or "en-US-AriaNeural"
        self.config.voice.tts_voice_ur = self.voice_ur_combo.currentData() or "ur-PK-UzmaNeural"
        self.config.voice.stt_language = self.stt_lang_combo.currentData() or "auto"
        self.config.ui.always_on_top = self.on_top_chk.isChecked()

        save_config(self.config)
        log.info("Settings updated successfully.")
        QMessageBox.information(self, "Saved", "Settings saved successfully!")
        self.accept()

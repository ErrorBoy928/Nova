"""
memory/database.py

SQLite-backed long-term memory: user preferences, conversation history,
custom commands, and learned user facts.
Stored in E:\\AI_Assistant\\data\\database\\memory.db.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Iterator

from utils.app_paths import user_data_dir
from utils.logger import get_logger

log = get_logger(__name__)

DB_PATH = user_data_dir() / "database" / "memory.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS preferences (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS conversation_history (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    role      TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content   TEXT NOT NULL,
    timestamp TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS custom_commands (
    trigger_phrase TEXT PRIMARY KEY,
    action         TEXT NOT NULL,
    created_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_facts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    fact       TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agent_tasks (
    id           TEXT PRIMARY KEY,
    title        TEXT NOT NULL,
    steps_json   TEXT NOT NULL,
    current_step INTEGER DEFAULT 0,
    status       TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);
"""


@contextmanager
def _connection() -> Iterator[sqlite3.Connection]:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    """Create tables if they don't exist yet. Safe to call on every startup."""
    with _connection() as conn:
        conn.executescript(SCHEMA)
    log.info("Memory database ready at {}", DB_PATH)


def set_preference(key: str, value: str) -> None:
    with _connection() as conn:
        conn.execute(
            "INSERT INTO preferences (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


def get_preference(key: str, default: str | None = None) -> str | None:
    with _connection() as conn:
        row = conn.execute(
            "SELECT value FROM preferences WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else default


def add_message(role: str, content: str) -> None:
    # Sanitize repetitive loops before saving
    import re
    clean_content = re.sub(r'(\S+)(?:\s+\1){2,}', r'\1', (content or "").strip(), flags=re.UNICODE)
    with _connection() as conn:
        conn.execute(
            "INSERT INTO conversation_history (role, content, timestamp) VALUES (?, ?, ?)",
            (role, clean_content, datetime.now().isoformat(timespec="seconds")),
        )


def get_recent_history(limit: int = 20) -> list[dict[str, str]]:
    """Return the last `limit` messages, oldest first."""
    import re
    with _connection() as conn:
        rows = conn.execute(
            "SELECT role, content FROM conversation_history ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    history = []
    for r in reversed(rows):
        c = re.sub(r'(\S+)(?:\s+\1){2,}', r'\1', r["content"], flags=re.UNICODE)
        history.append({"role": r["role"], "content": c})
    return history


def clear_history() -> None:
    with _connection() as conn:
        conn.execute("DELETE FROM conversation_history")


_MAX_FACTS = 150


def add_fact(fact: str) -> None:
    fact = fact.strip()
    if not fact:
        return
    with _connection() as conn:
        existing = conn.execute(
            "SELECT 1 FROM user_facts WHERE fact = ?", (fact,)
        ).fetchone()
        if existing:
            return
        conn.execute(
            "INSERT INTO user_facts (fact, created_at) VALUES (?, ?)",
            (fact, datetime.now().isoformat(timespec="seconds")),
        )
        count = conn.execute("SELECT COUNT(*) AS c FROM user_facts").fetchone()["c"]
        if count > _MAX_FACTS:
            conn.execute(
                "DELETE FROM user_facts WHERE id = ("
                "SELECT id FROM user_facts ORDER BY id ASC LIMIT 1)"
            )


def get_all_facts() -> list[str]:
    with _connection() as conn:
        rows = conn.execute("SELECT fact FROM user_facts ORDER BY id ASC").fetchall()
        return [r["fact"] for r in rows]


def clear_facts() -> None:
    with _connection() as conn:
        conn.execute("DELETE FROM user_facts")


# Compatibility aliases for actions and tests
remember_fact = add_fact
get_facts = get_all_facts


# ── Agent Tasks / Multi-Step Goals (Persistent Planner) ──────────────────────
import json
import uuid


def save_agent_task(title: str, steps: list[str], task_id: str | None = None) -> dict:
    """Saves or updates a structured multi-step agent task."""
    tid = task_id or f"task_{uuid.uuid4().hex[:8]}"
    now = datetime.now().isoformat(timespec="seconds")
    steps_clean = [s.strip() for s in steps if s.strip()]
    steps_json = json.dumps(steps_clean, ensure_ascii=False)

    with _connection() as conn:
        conn.execute(
            """INSERT INTO agent_tasks (id, title, steps_json, current_step, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                   title = excluded.title,
                   steps_json = excluded.steps_json,
                   updated_at = excluded.updated_at
            """,
            (tid, title.strip(), steps_json, 0, "in_progress", now, now)
        )
    return {
        "id": tid,
        "title": title.strip(),
        "steps": steps_clean,
        "current_step": 0,
        "status": "in_progress",
        "created_at": now,
        "updated_at": now,
    }


def update_agent_task_step(task_id: str, step_index: int, status: str = "in_progress") -> bool:
    now = datetime.now().isoformat(timespec="seconds")
    with _connection() as conn:
        res = conn.execute(
            "UPDATE agent_tasks SET current_step = ?, status = ?, updated_at = ? WHERE id = ?",
            (step_index, status, now, task_id)
        )
        return res.rowcount > 0


def complete_agent_task(task_id: str) -> bool:
    now = datetime.now().isoformat(timespec="seconds")
    with _connection() as conn:
        res = conn.execute(
            "UPDATE agent_tasks SET status = 'completed', updated_at = ? WHERE id = ?",
            (now, task_id)
        )
        return res.rowcount > 0


def delete_agent_task(task_id: str) -> bool:
    with _connection() as conn:
        res = conn.execute("DELETE FROM agent_tasks WHERE id = ?", (task_id,))
        return res.rowcount > 0


def get_active_agent_task() -> dict | None:
    with _connection() as conn:
        row = conn.execute(
            "SELECT * FROM agent_tasks WHERE status = 'in_progress' ORDER BY updated_at DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        return {
            "id": row["id"],
            "title": row["title"],
            "steps": json.loads(row["steps_json"]),
            "current_step": row["current_step"],
            "status": row["status"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }


def get_all_agent_tasks(limit: int = 30) -> list[dict]:
    with _connection() as conn:
        rows = conn.execute(
            "SELECT * FROM agent_tasks ORDER BY updated_at DESC LIMIT ?", (limit,)
        ).fetchall()
        tasks = []
        for r in rows:
            tasks.append({
                "id": r["id"],
                "title": r["title"],
                "steps": json.loads(r["steps_json"]),
                "current_step": r["current_step"],
                "status": r["status"],
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
            })
        return tasks



"""
automation/actions.py

Comprehensive Computer Control engine for the AI Assistant (JARVIS-grade).
Controls applications, system settings, files, audio, media, windows, screen,
keyboard, mouse, power, networking, hardware stats, and shell commands.
Each action returns (success: bool, message: str) for instant completion reporting.
"""

from __future__ import annotations

import ctypes
import json
import os
import re
import shutil
import subprocess
import time
import webbrowser
from pathlib import Path

from utils.app_paths import user_data_dir
from utils.logger import get_logger

log = get_logger(__name__)

ActionResult = tuple[bool, str]

# CREATE_NO_WINDOW flag guarantees that NO black console/PowerShell window flashes
_NO_WINDOW = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else (0x08000000 if os.name == "nt" else 0)


def _subp_run(cmd, **kwargs):
    """Subprocess runner that guarantees no visible console window on Windows."""
    if os.name == "nt":
        kwargs.setdefault("creationflags", _NO_WINDOW)
    return subprocess.run(cmd, **kwargs)


def _subp_popen(cmd, **kwargs):
    """Subprocess Popen that guarantees no visible console window on Windows."""
    if os.name == "nt":
        kwargs.setdefault("creationflags", _NO_WINDOW)
    return subprocess.Popen(cmd, **kwargs)

# Configure PyAutoGUI to avoid fail-safe crashes on corner coordinates
try:
    import pyautogui
    pyautogui.FAILSAFE = False
except Exception:
    pass


# ── 1. App Launching & Closing ──────────────────────────────────────────────
def open_application(name: str) -> ActionResult:
    """Launches any Windows application, system setting, Start Menu app, or web equivalent."""
    name = name.strip()
    if not name:
        return False, "No application name specified."

    name_lower = name.lower()

    # Pre-mapped common Windows utilities, settings & popular applications
    system_app_shortcuts = {
        # Accessories & Tools
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "calc": "calc.exe",
        "paint": "mspaint.exe",
        "mspaint": "mspaint.exe",
        "snipping tool": "snippingtool.exe",
        "snip": "snippingtool.exe",
        "camera": "microsoft.windows.camera:",
        "cleanmgr": "cleanmgr.exe",
        "disk cleanup": "cleanmgr.exe",
        "explorer": "explorer.exe",
        "file explorer": "explorer.exe",
        "my computer": "explorer.exe",
        "this pc": "explorer.exe",
        "cmd": "cmd.exe",
        "command prompt": "cmd.exe",
        "powershell": "powershell.exe",
        "terminal": "wt.exe",
        "windows terminal": "wt.exe",
        "task manager": "taskmgr.exe",
        "taskmgr": "taskmgr.exe",
        "control panel": "control.exe",
        "regedit": "regedit.exe",
        "device manager": "devmgmt.msc",
        "disk management": "diskmgmt.msc",
        "services": "services.msc",
        "recycle bin": "explorer.exe shell:RecycleBinFolder",
        # Windows Settings URIs
        "settings": "ms-settings:",
        "windows settings": "ms-settings:",
        "wifi": "ms-settings:network-wifi",
        "network": "ms-settings:network-wifi",
        "internet": "ms-settings:network",
        "bluetooth": "ms-settings:bluetooth",
        "sound": "ms-settings:sound",
        "sound settings": "ms-settings:sound",
        "volume settings": "ms-settings:sound",
        "display": "ms-settings:display",
        "display settings": "ms-settings:display",
        "battery": "ms-settings:batterysaver",
        "power settings": "ms-settings:powersleep",
        "apps": "ms-settings:appsfeatures",
        "installed apps": "ms-settings:appsfeatures",
        "updates": "ms-settings:windowsupdate",
        "windows update": "ms-settings:windowsupdate",
        "personalization": "ms-settings:personalization",
        # Browsers & Productivity
        "chrome": "chrome.exe",
        "google chrome": "chrome.exe",
        "edge": "msedge.exe",
        "microsoft edge": "msedge.exe",
        "firefox": "firefox.exe",
        "code": "code.cmd",
        "vs code": "code.cmd",
        "vscode": "code.cmd",
        "word": "winword.exe",
        "winword": "winword.exe",
        "excel": "excel.exe",
        "powerpoint": "powerpnt.exe",
        "spotify": "spotify.exe",
        "discord": "discord.exe",
        "vlc": "vlc.exe",
        "vlc media player": "vlc.exe",
    }

    target = system_app_shortcuts.get(name_lower, name)

    try:
        # Settings URIs or shell folders
        if target.startswith("ms-settings:") or target.startswith("microsoft.windows.") or "shell:" in target:
            _subp_popen(["cmd", "/c", "start", target])
            return True, f"Opened {name}."

        # In PATH, executable, or absolute path
        if shutil.which(target) or shutil.which(target + ".exe") or Path(target).exists():
            _subp_popen(["cmd", "/c", "start", "", target])
            log.info("Opened application: {}", target)
            return True, f"Opened {name}."

        # Check Windows App Paths in registry
        import winreg
        resolved = None
        for test_name in ([name, name + ".exe"] if not name.endswith(".exe") else [name]):
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                try:
                    key_path = f"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\{test_name}"
                    with winreg.OpenKey(hive, key_path) as k:
                        val, _ = winreg.QueryValueEx(k, "")
                        if val:
                            resolved = os.path.expandvars(str(val))
                            break
                except OSError:
                    continue
            if resolved:
                break

        if resolved and Path(resolved).exists():
            _subp_popen(["cmd", "/c", "start", "", resolved])
            return True, f"Opened {name}."

        # Search via PowerShell Get-StartApps
        cmd = ["powershell", "-NoProfile", "-Command", "Get-StartApps | ConvertTo-Json"]
        res = _subp_run(cmd, capture_output=True, text=True, timeout=5)
        if res.returncode == 0 and res.stdout.strip():
            apps_list = json.loads(res.stdout)
            if isinstance(apps_list, dict):
                apps_list = [apps_list]
            for app in apps_list:
                app_name = app.get("Name", "").lower()
                if name_lower in app_name or app_name in name_lower:
                    appid = app["AppID"]
                    _subp_popen(["explorer.exe", f"shell:AppsFolder\\{appid}"])
                    return True, f"Opened {app['Name']}."

        # Fallback web version for popular web services
        _WEB_APPS = {
            "whatsapp": "https://web.whatsapp.com",
            "youtube": "https://youtube.com",
            "gmail": "https://mail.google.com",
            "google": "https://google.com",
            "github": "https://github.com",
            "chatgpt": "https://chatgpt.com",
            "gemini": "https://gemini.google.com",
            "facebook": "https://facebook.com",
            "instagram": "https://instagram.com",
            "twitter": "https://x.com",
            "netflix": "https://netflix.com",
            "telegram": "https://web.telegram.org",
        }
        for kw, url in _WEB_APPS.items():
            if kw in name_lower:
                open_url(url)
                return True, f"Opened {name} in web browser."

        # Last resort: generic search
        open_url(f"https://www.google.com/search?q={name}")
        return True, f"Could not find local app '{name}'. Opened web search."
    except Exception as exc:
        log.warning("open_application error: {}", exc)
        return False, f"Failed to open {name}: {exc}"


def close_application(name: str) -> ActionResult:
    """Closes an open application or process by name."""
    name = name.strip()
    if not name:
        return False, "No application name provided to close."

    _EXE_MAP = {
        "chrome": "chrome.exe",
        "google chrome": "chrome.exe",
        "edge": "msedge.exe",
        "notepad": "notepad.exe",
        "calculator": "CalculatorApp.exe",
        "calc": "CalculatorApp.exe",
        "vlc": "vlc.exe",
        "spotify": "Spotify.exe",
        "discord": "Discord.exe",
        "code": "Code.exe",
        "vs code": "Code.exe",
        "word": "WINWORD.EXE",
        "excel": "EXCEL.EXE",
        "powerpoint": "POWERPNT.EXE",
        "taskmgr": "taskmgr.exe",
        "task manager": "taskmgr.exe",
    }
    proc_name = _EXE_MAP.get(name.lower(), name if name.endswith(".exe") else f"{name}.exe")

    try:
        cmd = ["taskkill", "/f", "/im", proc_name]
        res = _subp_run(cmd, capture_output=True, text=True, timeout=5)
        if res.returncode == 0:
            log.info("Closed application: {}", proc_name)
            return True, f"Closed {name}."
        else:
            # Try closing by window title via PowerShell
            ps_cmd = f'Get-Process | Where-Object {{ $_.MainWindowTitle -like "*{name}*" }} | Stop-Process -Force'
            res2 = _subp_run(["powershell", "-NoProfile", "-Command", ps_cmd], capture_output=True, text=True, timeout=5)
            if res2.returncode == 0:
                return True, f"Closed {name} window."
            return False, f"Could not find running process for '{name}'."
    except Exception as exc:
        return False, f"Error closing {name}: {exc}"


def focus_application(name: str) -> ActionResult:
    """Brings an application window to the foreground by name."""
    name = name.strip()
    if not name:
        return False, "No application name provided."
    try:
        ps_cmd = f"(New-Object -ComObject WScript.Shell).AppActivate('{name}')"
        res = _subp_run(["powershell", "-NoProfile", "-Command", ps_cmd], capture_output=True, text=True, timeout=4)
        if "True" in res.stdout:
            return True, f"Brought '{name}' window to front."
        return False, f"Could not find running window for '{name}'."
    except Exception as exc:
        return False, f"Focus error: {exc}"


def kill_process(name_or_pid: str) -> ActionResult:
    """Forcefully terminates an unresponsive process by name or PID."""
    target = name_or_pid.strip()
    if not target:
        return False, "No process name or PID specified."
    try:
        if target.isdigit():
            cmd = ["taskkill", "/f", "/pid", target]
        else:
            proc = target if target.endswith(".exe") else f"{target}.exe"
            cmd = ["taskkill", "/f", "/im", proc]
        res = _subp_run(cmd, capture_output=True, text=True, timeout=5)
        if res.returncode == 0:
            return True, f"Terminated process: {target}"
        return False, f"Could not find or terminate process '{target}'."
    except Exception as exc:
        return False, f"Process kill error: {exc}"




# ── 2. Audio & Media Controls ────────────────────────────────────────────────
def set_volume(level: str) -> ActionResult:
    """Sets master volume percentage (0-100) or changes it (up/down)."""
    try:
        lvl_str = level.strip().lower()
        if lvl_str in ("up", "increase", "+", "louder"):
            return volume_up()
        if lvl_str in ("down", "decrease", "-", "quieter", "lower"):
            return volume_down()
        if lvl_str in ("mute", "unmute", "toggle"):
            return toggle_mute()

        pct = int(re.sub(r"[^\d]", "", lvl_str))
        pct = max(0, min(100, pct))
        ps_cmd = f'''
        $obj = New-Object -ComObject WScript.Shell
        1..50 | ForEach-Object {{ $obj.SendKeys([char]174) }}
        1..{int(pct / 2)} | ForEach-Object {{ $obj.SendKeys([char]175) }}
        '''
        _subp_run(["powershell", "-NoProfile", "-Command", ps_cmd], capture_output=True, timeout=5)
        return True, f"Set master volume to {pct}%."
    except Exception as exc:
        return False, f"Volume adjustment error: {exc}"


def volume_up() -> ActionResult:
    try:
        import pyautogui
        for _ in range(5):
            pyautogui.press("volumeup")
        return True, "Volume increased."
    except Exception as exc:
        return False, f"Failed: {exc}"


def volume_down() -> ActionResult:
    try:
        import pyautogui
        for _ in range(5):
            pyautogui.press("volumedown")
        return True, "Volume decreased."
    except Exception as exc:
        return False, f"Failed: {exc}"


def toggle_mute() -> ActionResult:
    try:
        import pyautogui
        pyautogui.press("volumemute")
        return True, "Volume mute toggled."
    except Exception as exc:
        return False, f"Failed: {exc}"


def media_control(action: str) -> ActionResult:
    try:
        import pyautogui
        action = action.strip().lower()
        if action in ("play", "pause", "playpause", "toggle"):
            pyautogui.press("playpause")
            return True, "Toggled media Play/Pause."
        elif action in ("next", "skip"):
            pyautogui.press("nexttrack")
            return True, "Skipped to next track."
        elif action in ("prev", "previous", "back"):
            pyautogui.press("prevtrack")
            return True, "Skipped to previous track."
        elif action in ("stop",):
            pyautogui.press("stop")
            return True, "Stopped media playback."
        return False, f"Unknown media action: {action}"
    except Exception as exc:
        return False, f"Media control error: {exc}"


def get_brightness() -> ActionResult:
    """Gets current screen brightness percentage (0-100)."""
    try:
        cmd = "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness -ErrorAction SilentlyContinue).CurrentBrightness"
        res = _subp_run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True, timeout=4)
        out = res.stdout.strip()
        if out and out.isdigit():
            return True, f"Screen brightness is currently {out}%."
        return False, "Screen brightness is not supported on this display."
    except Exception as exc:
        return False, f"Could not get brightness: {exc}"


def set_brightness(level: str) -> ActionResult:
    """Sets screen brightness percentage (0-100) or increments/decrements (up/down)."""
    try:
        lvl = level.strip().lower()
        curr_pct = 70
        ok_cur, cur_msg = get_brightness()
        if ok_cur:
            nums = re.findall(r"\d+", cur_msg)
            if nums:
                curr_pct = int(nums[0])

        if lvl in ("up", "increase", "+", "brighter", "more"):
            target = min(100, curr_pct + 15)
        elif lvl in ("down", "decrease", "-", "dimmer", "dim", "less"):
            target = max(10, curr_pct - 15)
        else:
            num = re.sub(r"[^\d]", "", lvl)
            target = max(5, min(100, int(num))) if num else 70

        cmd = f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods -ErrorAction SilentlyContinue).WmiSetBrightness(1, {target})"
        _subp_run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, timeout=5)
        return True, f"Set screen brightness to {target}%."
    except Exception as exc:
        return False, f"Could not set brightness: {exc}"



# ── 3. Window & Desktop Management ──────────────────────────────────────────
def minimize_active_window() -> ActionResult:
    try:
        import pyautogui
        pyautogui.hotkey("win", "down")
        return True, "Minimized active window."
    except Exception as exc:
        return False, f"Failed: {exc}"


def maximize_active_window() -> ActionResult:
    try:
        import pyautogui
        pyautogui.hotkey("win", "up")
        return True, "Maximized active window."
    except Exception as exc:
        return False, f"Failed: {exc}"


def show_desktop() -> ActionResult:
    try:
        import pyautogui
        pyautogui.hotkey("win", "d")
        return True, "Displaying Windows desktop."
    except Exception as exc:
        return False, f"Failed: {exc}"


def switch_window() -> ActionResult:
    try:
        import pyautogui
        pyautogui.hotkey("alt", "tab")
        return True, "Switched active window."
    except Exception as exc:
        return False, f"Failed: {exc}"


def close_active_window() -> ActionResult:
    try:
        import pyautogui
        pyautogui.hotkey("alt", "f4")
        return True, "Closed active window."
    except Exception as exc:
        return False, f"Failed: {exc}"


def snap_window(direction: str) -> ActionResult:
    try:
        import pyautogui
        d = direction.strip().lower()
        if "left" in d:
            pyautogui.hotkey("win", "left")
            return True, "Snapped window to left."
        elif "right" in d:
            pyautogui.hotkey("win", "right")
            return True, "Snapped window to right."
        elif "up" in d or "max" in d:
            pyautogui.hotkey("win", "up")
            return True, "Maximized window."
        elif "down" in d or "min" in d:
            pyautogui.hotkey("win", "down")
            return True, "Minimized window."
        return False, f"Unknown snap direction: {direction}"
    except Exception as exc:
        return False, f"Failed: {exc}"


# ── 4. File & Folder Operations ──────────────────────────────────────────────
def _resolve_special_folder(name: str) -> Path:
    name_l = name.strip().lower()
    home = Path.home()
    if name_l in ("desktop", "desk"):
        return home / "Desktop"
    if name_l in ("downloads", "download"):
        return home / "Downloads"
    if name_l in ("documents", "doc", "docs"):
        return home / "Documents"
    if name_l in ("pictures", "photos", "images"):
        return home / "Pictures"
    if name_l in ("music", "songs"):
        return home / "Music"
    if name_l in ("videos", "movies"):
        return home / "Videos"
    if name_l in ("c", "c:", "c:\\"):
        return Path("C:\\")
    if name_l in ("e", "e:", "e:\\"):
        return Path("E:\\")
    if name_l in ("project", "ai_assistant"):
        return Path("E:\\AI_Assistant")
    p = Path(os.path.expandvars(name.strip()))
    if not p.is_absolute() and not p.exists():
        p_desk = home / "Desktop" / p
        if p_desk.exists():
            return p_desk
    return p


def open_folder(folder_name: str) -> ActionResult:
    """Opens a folder in Windows File Explorer."""
    p = _resolve_special_folder(folder_name)
    if not p.exists():
        return False, f"Folder does not exist: {p}"
    try:
        _subp_popen(["explorer.exe", str(p)])
        return True, f"Opened folder: {p}"
    except Exception as exc:
        return False, f"Could not open folder: {exc}"


def create_file(path_str: str, content: str = "") -> ActionResult:
    """Creates a text file at the specified path with optional content (defaults to Desktop if relative)."""
    try:
        raw = path_str.strip()
        p = Path(os.path.expandvars(raw))
        if not p.is_absolute():
            p = Path.home() / "Desktop" / p
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return True, f"Created file: {p.name} on {p.parent}"
    except Exception as exc:
        return False, f"Could not create file: {exc}"


def append_file(path_str: str, content: str = "") -> ActionResult:
    """Appends text to a file (defaults to Desktop if relative)."""
    try:
        raw = path_str.strip()
        p = Path(os.path.expandvars(raw))
        if not p.is_absolute():
            p = Path.home() / "Desktop" / p
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            f.write("\n" + content if p.exists() and p.stat().st_size > 0 else content)
        return True, f"Updated file: {p.name}"
    except Exception as exc:
        return False, f"Could not append to file: {exc}"


def create_folder(path_str: str) -> ActionResult:
    """Creates a directory at the specified path (defaults to Desktop if relative)."""
    try:
        p = Path(os.path.expandvars(path_str.strip()))
        if not p.is_absolute():
            p = Path.home() / "Desktop" / p
        p.mkdir(parents=True, exist_ok=True)
        return True, f"Created folder: {p}"
    except Exception as exc:
        return False, f"Could not create directory: {exc}"


def read_file(path_str: str) -> ActionResult:
    """Reads content from a text file."""
    try:
        p = Path(os.path.expandvars(path_str.strip()))
        if not p.is_absolute():
            # Check desktop first
            p_desk = Path.home() / "Desktop" / p
            if p_desk.exists():
                p = p_desk
        if not p.exists():
            return False, f"File not found: {p}"
        text = p.read_text(encoding="utf-8", errors="replace")
        preview = text[:2000] + ("\n...(truncated)" if len(text) > 2000 else "")
        return True, f"File Content ({p.name}):\n{preview}"
    except Exception as exc:
        return False, f"Could not read file: {exc}"


def delete_item(path_str: str) -> ActionResult:
    """Deletes a file or directory."""
    try:
        p = Path(os.path.expandvars(path_str.strip()))
        if not p.is_absolute():
            p_desk = Path.home() / "Desktop" / p
            if p_desk.exists():
                p = p_desk
        if not p.exists():
            return False, f"Item not found: {p}"
        if p.is_dir():
            shutil.rmtree(p)
            return True, f"Deleted folder: {p.name}"
        else:
            p.unlink()
            return True, f"Deleted file: {p.name}"
    except Exception as exc:
        return False, f"Could not delete: {exc}"


def list_directory(path_str: str) -> ActionResult:
    """Lists files and folders inside a directory."""
    p = _resolve_special_folder(path_str) if path_str else Path.home() / "Desktop"
    if not p.exists():
        return False, f"Directory does not exist: {p}"
    try:
        items = os.listdir(p)[:30]
        summary = "\n".join(f"- {it}" for it in items)
        return True, f"Contents of {p.name or p}:\n{summary}"
    except Exception as exc:
        return False, f"Could not list directory: {exc}"


def search_files(query: str, drive: str = "E:") -> ActionResult:
    """Searches for files matching a query on the designated drive or folder."""
    query = query.strip()
    drive = drive.strip() or "E:"
    try:
        cmd = f'Get-ChildItem -Path "{drive}\\" -Filter "*{query}*" -Recurse -ErrorAction SilentlyContinue -Depth 3 | Select-Object -First 10 FullName | ConvertTo-Json'
        res = _subp_run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True, timeout=8)
        if res.returncode == 0 and res.stdout.strip():
            raw = json.loads(res.stdout)
            if isinstance(raw, list):
                files = [f.get("FullName", str(f)) for f in raw]
            elif isinstance(raw, dict):
                files = [raw.get("FullName", str(raw))]
            else:
                files = [str(raw)]
            return True, f"Found {len(files)} files matching '{query}':\n" + "\n".join(f"- {f}" for f in files)
        return False, f"No files matching '{query}' found on {drive}."
    except Exception as exc:
        return False, f"Search failed: {exc}"


def zip_item(path_str: str) -> ActionResult:
    """Creates a zip archive of a file or folder (defaults to Desktop if relative)."""
    import zipfile
    try:
        p = Path(os.path.expandvars(path_str.strip()))
        if not p.is_absolute():
            p_desk = Path.home() / "Desktop" / p
            if p_desk.exists():
                p = p_desk
        if not p.exists():
            return False, f"Item not found: {p}"
        out_zip = p.parent / f"{p.stem}.zip"
        if p.is_dir():
            shutil.make_archive(str(p.parent / p.stem), "zip", p)
        else:
            with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.write(p, arcname=p.name)
        return True, f"Archived '{p.name}' to {out_zip.name}"
    except Exception as exc:
        return False, f"Zip error: {exc}"


def unzip_item(path_str: str) -> ActionResult:
    """Extracts a zip file into a folder."""
    import zipfile
    try:
        p = Path(os.path.expandvars(path_str.strip()))
        if not p.is_absolute():
            p_desk = Path.home() / "Desktop" / p
            if p_desk.exists():
                p = p_desk
        if not p.exists() or not p.name.endswith(".zip"):
            return False, f"Zip archive not found: {p}"
        dest_dir = p.parent / p.stem
        dest_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(p, "r") as zf:
            zf.extractall(dest_dir)
        return True, f"Extracted '{p.name}' into folder '{dest_dir.name}'"
    except Exception as exc:
        return False, f"Unzip error: {exc}"



# ── 5. System, Power, Clean & Hardware Info ──────────────────────────────────
def system_power(action: str) -> ActionResult:
    """Manages system power: lock, sleep, restart, shutdown, cancel."""
    action = action.strip().lower()
    try:
        if action == "lock":
            ctypes.windll.user32.LockWorkStation()
            return True, "Workstation locked, sir."
        elif action == "sleep":
            _subp_popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
            return True, "Putting computer to sleep."
        elif action in ("restart", "reboot"):
            _subp_popen(["shutdown", "/r", "/t", "10", "/c", "JARVIS restarting system."])
            return True, "System will restart in 10 seconds. (Say 'cancel shutdown' to abort)."
        elif action == "shutdown":
            _subp_popen(["shutdown", "/s", "/t", "15", "/c", "JARVIS shutting down system."])
            return True, "System will shut down in 15 seconds. (Say 'cancel shutdown' to abort)."
        elif action in ("cancel", "cancel_shutdown", "abort"):
            _subp_run(["shutdown", "/a"], capture_output=True)
            return True, "Scheduled shutdown or restart aborted."
        return False, f"Unknown power action: {action}"
    except Exception as exc:
        return False, f"Power command error: {exc}"


def empty_recycle_bin() -> ActionResult:
    try:
        flags = 0x00000007  # SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
        ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, flags)
        return True, "Recycle Bin has been emptied."
    except Exception as exc:
        return False, f"Could not empty Recycle Bin: {exc}"


def clear_temp_files() -> ActionResult:
    """Cleans Windows temporary files to free disk space."""
    try:
        temp_dir = Path(os.environ.get("TEMP", "C:\\Windows\\Temp"))
        cleaned_count = 0
        cleaned_bytes = 0
        for item in temp_dir.glob("*"):
            try:
                if item.is_file():
                    cleaned_bytes += item.stat().st_size
                    item.unlink()
                    cleaned_count += 1
                elif item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                    cleaned_count += 1
            except Exception:
                pass
        freed_mb = round(cleaned_bytes / (1024 * 1024), 1)
        return True, f"Cleaned {cleaned_count} temporary items ({freed_mb} MB freed)."
    except Exception as exc:
        return False, f"Clean temp error: {exc}"


def get_system_stats() -> ActionResult:
    """Returns disk space for C: and E:, available RAM, and CPU status."""
    try:
        cmd = '''
        $c = Get-PSDrive C; $e = Get-PSDrive E;
        $cFree = [math]::Round($c.Free / 1GB, 2);
        $eFree = [math]::Round($e.Free / 1GB, 2);
        $os = Get-CimInstance Win32_OperatingSystem;
        $freeRam = [math]::Round($os.FreePhysicalMemory / 1MB, 2);
        $totalRam = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2);
        "Drive C Free: $cFree GB | Drive E Free: $eFree GB | RAM: $freeRam GB available of $totalRam GB"
        '''
        res = _subp_run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True, timeout=5)
        stats = res.stdout.strip() or "Stats currently unavailable."
        return True, stats
    except Exception as exc:
        return False, f"Could not get stats: {exc}"


def get_battery_status() -> ActionResult:
    """Returns laptop battery percentage and charging state."""
    try:
        cmd = "Get-CimInstance Win32_Battery | Select-Object -ExpandProperty EstimatedChargeRemaining"
        res = _subp_run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True, timeout=4)
        pct = res.stdout.strip()
        if pct.isdigit():
            return True, f"Battery level is at {pct}%."
        return True, "Running on AC power / Desktop power supply."
    except Exception as exc:
        return False, f"Battery check error: {exc}"


def get_wifi_status() -> ActionResult:
    """Returns connected Wi-Fi SSID and signal strength."""
    try:
        res = _subp_run(["netsh", "wlan", "show", "interfaces"], capture_output=True, text=True, timeout=4)
        out = res.stdout
        ssid_match = re.search(r"^\s*SSID\s*:\s*(.+)$", out, re.MULTILINE)
        signal_match = re.search(r"^\s*Signal\s*:\s*(.+)$", out, re.MULTILINE)
        state_match = re.search(r"^\s*State\s*:\s*(.+)$", out, re.MULTILINE)

        if ssid_match:
            ssid = ssid_match.group(1).strip()
            signal = signal_match.group(1).strip() if signal_match else "Good"
            state = state_match.group(1).strip() if state_match else "Connected"
            return True, f"Wi-Fi Status: {state} to '{ssid}' (Signal: {signal})."
        return True, "No active Wi-Fi connection detected."
    except Exception as exc:
        return False, f"Wi-Fi check error: {exc}"


def get_top_processes(count: int = 5) -> ActionResult:
    """Lists top active processes using the most memory."""
    try:
        cmd = f"Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First {count} ProcessName, Id | Out-String"
        res = _subp_run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True, timeout=5)
        output = res.stdout.strip()
        return True, f"Top active processes:\n{output}"
    except Exception as exc:
        return False, f"Process check error: {exc}"


def get_network_info() -> ActionResult:
    """Provides full network telemetry: Hostname, Local IP, Wi-Fi status, and Internet latency."""
    try:
        import socket
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        _, wifi = get_wifi_status()
        ping_res = _subp_run(["ping", "-n", "1", "-w", "1000", "8.8.8.8"], capture_output=True, text=True)
        online = ping_res.returncode == 0
        status_line = "Internet: Connected (Online)" if online else "Internet: Offline"
        return True, f"Network Telemetry:\n- Hostname: {hostname}\n- Local IP: {local_ip}\n- {wifi}\n- {status_line}"
    except Exception as exc:
        return False, f"Network check error: {exc}"



# ── 6. Keyboard, Mouse & Screen ──────────────────────────────────────────────
def _capture_screen_image():
    """Captures the primary screen using Qt or Windows GDI BitBlt (rock-solid)."""
    # 1. Qt Screen Grab if PySide6 application is running
    try:
        from PySide6.QtGui import QGuiApplication
        screen = QGuiApplication.primaryScreen()
        if screen:
            pix = screen.grabWindow(0)
            if not pix.isNull():
                import io
                from PIL import Image
                from PySide6.QtCore import QBuffer, QIODevice
                buf = QBuffer()
                buf.open(QIODevice.ReadWrite)
                pix.save(buf, "PNG")
                return Image.open(io.BytesIO(buf.data()))
    except Exception:
        pass

    # 2. Windows GDI BitBlt (never fails on Windows)
    try:
        from ctypes import windll, wintypes, byref
        from PIL import Image

        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [
                ('biSize', wintypes.DWORD),
                ('biWidth', wintypes.LONG),
                ('biHeight', wintypes.LONG),
                ('biPlanes', wintypes.WORD),
                ('biBitCount', wintypes.WORD),
                ('biCompression', wintypes.DWORD),
                ('biSizeImage', wintypes.DWORD),
                ('biXPelsPerMeter', wintypes.LONG),
                ('biYPelsPerMeter', wintypes.LONG),
                ('biClrUsed', wintypes.DWORD),
                ('biClrImportant', wintypes.DWORD)
            ]

        user32 = windll.user32
        gdi32 = windll.gdi32
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass
        w = user32.GetSystemMetrics(0)
        h = user32.GetSystemMetrics(1)
        hdc_screen = user32.GetDC(0)
        hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
        hbm = gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
        old_bmp = gdi32.SelectObject(hdc_mem, hbm)
        gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_screen, 0, 0, 0x00CC0020)

        bmi = BITMAPINFOHEADER()
        bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.biWidth = w
        bmi.biHeight = -h
        bmi.biPlanes = 1
        bmi.biBitCount = 32
        bmi.biCompression = 0

        buf = (ctypes.c_ubyte * (w * h * 4))()
        gdi32.GetDIBits(hdc_mem, hbm, 0, h, buf, byref(bmi), 0)

        gdi32.SelectObject(hdc_mem, old_bmp)
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(0, hdc_screen)

        img = Image.frombuffer('RGBA', (w, h), buf, 'raw', 'BGRA', 0, 1)
        return img.convert('RGB')
    except Exception:
        pass

    # 3. Fallback to PIL ImageGrab
    from PIL import ImageGrab
    return ImageGrab.grab()


def take_screenshot(filename: str = "") -> ActionResult:
    """Takes a full screen screenshot and saves it to Desktop."""
    try:
        target_dir = Path.home() / "Desktop"
        target_dir.mkdir(parents=True, exist_ok=True)
        name = filename.strip() or f"screenshot_{int(time.time())}.png"
        if not name.endswith(".png"):
            name += ".png"
        save_path = target_dir / name
        img = _capture_screen_image()
        img.save(str(save_path))
        return True, f"Screenshot saved to Desktop: {save_path.name}"
    except Exception as exc:
        return False, f"Screenshot error: {exc}"



def type_text(text: str) -> ActionResult:
    """Types text into the currently focused window."""
    try:
        import pyautogui
        pyautogui.write(text, interval=0.01)
        return True, f"Typed {len(text)} characters into active window."
    except Exception as exc:
        return False, f"Typing error: {exc}"


def press_hotkey(keys_str: str) -> ActionResult:
    """Presses keyboard shortcut like 'ctrl+c', 'alt+f4', 'win+r', 'enter', 'win+d'."""
    try:
        import pyautogui
        parts = [k.strip().lower() for k in keys_str.split("+")]
        pyautogui.hotkey(*parts)
        return True, f"Executed hotkey: {keys_str}"
    except Exception as exc:
        return False, f"Hotkey error: {exc}"


def click_at(coords: str) -> ActionResult:
    """Clicks on screen percentage coordinates (e.g. '50,50' for screen center)."""
    try:
        import pyautogui
        parts = coords.split(",")
        x_pct, y_pct = float(parts[0].strip()), float(parts[1].strip())
        if x_pct > 100.0 or y_pct > 100.0:
            x_pct, y_pct = x_pct / 10.0, y_pct / 10.0
        w, h = pyautogui.size()
        x, y = int((x_pct / 100.0) * w), int((y_pct / 100.0) * h)
        pyautogui.moveTo(x, y, duration=0.2)
        pyautogui.click()
        return True, f"Clicked at ({x_pct}%, {y_pct}%)."
    except Exception as exc:
        return False, f"Click error: {exc}"


def click_and_type(args: str) -> ActionResult:
    """Clicks at screen percentage coordinates and types text."""
    try:
        import pyautogui
        import time
        parts = args.split(",", 2)
        x_pct, y_pct, text = float(parts[0].strip()), float(parts[1].strip()), parts[2]
        if x_pct > 100.0 or y_pct > 100.0:
            x_pct, y_pct = x_pct / 10.0, y_pct / 10.0
        w, h = pyautogui.size()
        x, y = int((x_pct / 100.0) * w), int((y_pct / 100.0) * h)
        pyautogui.moveTo(x, y, duration=0.2)
        pyautogui.click()
        time.sleep(0.1)
        press_enter = text.endswith(("\n", "\\n"))
        clean = text.rstrip("\n\\n")
        pyautogui.write(clean, interval=0.01)
        if press_enter:
            pyautogui.press("enter")
        return True, f"Clicked at ({x_pct}%, {y_pct}%) and typed text."
    except Exception as exc:
        return False, f"Click and type error: {exc}"


def clipboard_copy(text: str) -> ActionResult:
    """Copies text to the Windows clipboard."""
    try:
        import pyperclip
        pyperclip.copy(text)
        return True, f"Copied {len(text)} characters to clipboard."
    except Exception as exc:
        return False, f"Clipboard error: {exc}"


def clipboard_read() -> ActionResult:
    """Reads text from the Windows clipboard."""
    try:
        import pyperclip
        content = pyperclip.paste()
        if not content:
            return False, "Clipboard is currently empty."
        preview = content[:500] + ("\n...(truncated)" if len(content) > 500 else "")
        return True, f"Clipboard Content:\n{preview}"
    except Exception as exc:
        return False, f"Clipboard error: {exc}"



# ── 7. Web & Shell Commands ──────────────────────────────────────────────────
def open_url(url: str) -> ActionResult:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        webbrowser.open(url)
        return True, f"Opened URL: {url}"
    except Exception as exc:
        return False, f"Error opening URL: {exc}"


def google_search(query: str) -> ActionResult:
    import urllib.parse
    return open_url(f"https://www.google.com/search?q={urllib.parse.quote(query.strip())}")


def youtube_search(query: str) -> ActionResult:
    import urllib.parse
    return open_url(f"https://www.youtube.com/results?search_query={urllib.parse.quote(query.strip())}")


def run_command(command_str: str) -> ActionResult:
    """Executes a shell or PowerShell command silently and captures the output."""
    cmd = command_str.strip()
    if not cmd:
        return False, "No command provided."
    try:
        res = _subp_run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True,
            text=True,
            timeout=25,
        )
        out = (res.stdout or "").strip()
        err = (res.stderr or "").strip()
        result_text = out if out else (err if err else "Command executed successfully.")
        if len(result_text) > 1500:
            result_text = result_text[:1500] + "\n...(truncated)"
        return res.returncode == 0, result_text
    except Exception as exc:
        return False, f"Execution failed: {exc}"


def calculate(expr: str) -> ActionResult:
    """Safely calculates arithmetic expressions offline (e.g. '15% of 8500', '(120 * 4) + 50')."""
    try:
        clean = expr.strip().lower()
        pct_match = re.search(r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)", clean)
        if pct_match:
            pct_val = float(pct_match.group(1))
            total_val = float(pct_match.group(2))
            res = (pct_val / 100.0) * total_val
            return True, f"{pct_val}% of {total_val} = {res}"
        sanitized = re.sub(r"[^0-9\+\-\*\/\(\)\.\s\^]", "", clean).replace("^", "**")
        if not sanitized.strip():
            return False, "Invalid math expression."
        val = eval(sanitized, {"__builtins__": None}, {})
        return True, f"Calculation: {expr.strip()} = {val}"
    except Exception as exc:
        return False, f"Could not calculate: {exc}"


def run_routine(routine_name: str) -> ActionResult:
    """Executes preset smart routines: 'work', 'relax', 'clean', 'status', 'night'."""
    name = routine_name.strip().lower()
    reports = []
    if name in ("work", "focus", "study"):
        set_volume("25")
        reports.append("Volume set to 25%")
        open_application("chrome")
        reports.append("Opened browser workspace")
        return True, "Focus routine activated: " + ", ".join(reports)
    elif name in ("relax", "chill", "music"):
        set_volume("45")
        reports.append("Volume set to 45%")
        youtube_search("lofi chill beats")
        reports.append("Launched background music")
        return True, "Relax routine activated: " + ", ".join(reports)
    elif name in ("night", "sleep_mode", "dim"):
        set_volume("15")
        set_brightness("25")
        reports.append("Volume set to 15%")
        reports.append("Screen brightness dimmed to 25%")
        return True, "Night routine activated: " + ", ".join(reports)
    elif name in ("clean", "speedup", "turbo"):
        ok_t, msg_t = clear_temp_files()
        ok_r, msg_r = empty_recycle_bin()
        return True, f"System cleanup completed. {msg_t} | {msg_r}"
    elif name in ("status", "health", "specs"):
        _, stats = get_system_stats()
        _, wifi = get_wifi_status()
        _, bat = get_battery_status()
        _, bri = get_brightness()
        return True, f"System Health:\n- {stats}\n- {wifi}\n- {bat}\n- {bri}"
    return False, f"Unknown routine: {routine_name}"


# ── 8. Coding & Developer Actions ──────────────────────────────────────────
def run_code(arg: str) -> ActionResult:
    """Executes code snippet in Python, PowerShell, CMD, or Node.
    Syntax: 'python:code' or 'powershell:code' or just Python code.
    """
    arg = arg.strip()
    if not arg:
        return False, "No code provided to execute."

    lang = "python"
    code = arg
    if ":" in arg:
        possible_lang, rest = arg.split(":", 1)
        if possible_lang.strip().lower() in ("python", "py", "powershell", "ps", "ps1", "cmd", "bat", "batch", "node", "js", "javascript"):
            lang = possible_lang.strip().lower()
            code = rest.strip()

    import tempfile
    import sys

    try:
        if lang in ("python", "py"):
            py_bin = sys.executable or "E:\\python\\python.exe"
            with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as f:
                f.write(code)
                tmp_path = f.name
            try:
                proc = subprocess.run(
                    [py_bin, tmp_path],
                    capture_output=True,
                    text=True,
                    timeout=25,
                    creationflags=0x08000000 if os.name == "nt" else 0,
                )
                stdout = proc.stdout.strip()
                stderr = proc.stderr.strip()
                out = stdout or stderr or "(Execution completed with no output)"
                status = "Success" if proc.returncode == 0 else f"Failed (exit {proc.returncode})"
                return (proc.returncode == 0), f"Python [{status}]:\n{out}"
            finally:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

        elif lang in ("powershell", "ps", "ps1"):
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", code],
                capture_output=True,
                text=True,
                timeout=25,
                creationflags=0x08000000 if os.name == "nt" else 0,
            )
            out = proc.stdout.strip() or proc.stderr.strip() or "(Finished)"
            return (proc.returncode == 0), f"PowerShell (exit {proc.returncode}):\n{out}"

        elif lang in ("cmd", "bat", "batch"):
            proc = subprocess.run(
                ["cmd.exe", "/c", code],
                capture_output=True,
                text=True,
                timeout=25,
                creationflags=0x08000000 if os.name == "nt" else 0,
            )
            out = proc.stdout.strip() or proc.stderr.strip() or "(Finished)"
            return (proc.returncode == 0), f"CMD (exit {proc.returncode}):\n{out}"

        elif lang in ("node", "js", "javascript"):
            proc = subprocess.run(
                ["node", "-e", code],
                capture_output=True,
                text=True,
                timeout=25,
                creationflags=0x08000000 if os.name == "nt" else 0,
            )
            out = proc.stdout.strip() or proc.stderr.strip() or "(Finished)"
            return (proc.returncode == 0), f"Node.js (exit {proc.returncode}):\n{out}"

        return False, f"Unsupported language: {lang}"
    except subprocess.TimeoutExpired:
        return False, "Code execution timed out (limit: 25s)."
    except Exception as exc:
        return False, f"Code execution error: {exc}"


def save_code_file(arg: str) -> ActionResult:
    """Saves code to a file. Syntax: 'filepath:content' or saves to Desktop."""
    if ":" not in arg:
        return False, "Invalid format. Expected 'filepath:content'."
    path_str, content = arg.split(":", 1)
    p = Path(path_str.strip())
    if not p.is_absolute():
        p = Path.home() / "Desktop" / p
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content.strip(), encoding="utf-8")
        return True, f"Saved code file: {p}"
    except Exception as exc:
        return False, f"Could not save file: {exc}"


def run_git(args: str) -> ActionResult:
    """Runs a git command (e.g. status, diff, log, commit)."""
    args = args.strip()
    if not args:
        return False, "No git command provided."
    try:
        cmd = ["git"] + args.split()
        proc = _subp_run(cmd, capture_output=True, text=True, timeout=20)
        out = proc.stdout.strip() or proc.stderr.strip() or "(Git command executed)"
        return (proc.returncode == 0), f"Git ({'OK' if proc.returncode == 0 else 'Error'}):\n{out}"
    except Exception as exc:
        return False, f"Git execution error: {exc}"


def pip_install(package: str) -> ActionResult:
    """Installs a Python package using pip."""
    pkg = package.strip()
    if not pkg:
        return False, "No package specified."
    import sys
    py_bin = sys.executable or "E:\\python\\python.exe"
    try:
        proc = _subp_run(
            [py_bin, "-m", "pip", "install", pkg],
            capture_output=True,
            text=True,
            timeout=90,
        )
        out = proc.stdout.strip() or proc.stderr.strip()
        return (proc.returncode == 0), f"pip install {pkg} (exit {proc.returncode}):\n{out}"
    except Exception as exc:
        return False, f"Pip error: {exc}"


# ── 9. Vision & Agent Task Management ──────────────────────────────────────────
def enable_screen_vision() -> ActionResult:
    """Activates screen vision and captures initial screen state."""
    try:
        from automation.screen_observer import screen_observer
        screen_observer.set_enabled(True)
        shot_path, win_title = screen_observer.capture_now()
        return True, f"Screen Vision is now ON. Active window: '{win_title}'."
    except Exception as exc:
        return False, f"Could not activate screen vision: {exc}"


def save_agent_task(arg: str) -> ActionResult:
    """Saves a multi-step agent task or goal to persistent storage.
    Format: 'Title:Step 1|Step 2|Step 3' or 'Title'
    """
    arg = arg.strip()
    if not arg:
        return False, "No task description or title provided."
    if ":" in arg:
        title, steps_raw = arg.split(":", 1)
        steps = [s.strip() for s in steps_raw.split("|") if s.strip()]
    else:
        title = arg
        steps = ["Analyze requirements", "Execute solution", "Verify results"]

    try:
        import memory.database as db
        task = db.save_agent_task(title.strip(), steps)
        return True, f"Agent Task saved: '{title.strip()}' ({len(steps)} steps). Task ID: {task['id']}"
    except Exception as exc:
        return False, f"Failed to save agent task: {exc}"


def update_agent_task_progress(arg: str) -> ActionResult:
    """Updates progress on an active agent task.
    Format: 'task_id:step_number' or 'task_id:completed' or 'step_number'
    """
    arg = arg.strip()
    try:
        import memory.database as db
        task = db.get_active_agent_task()
        task_id = None
        step_idx = 0
        status = "in_progress"

        if ":" in arg:
            tid_part, step_part = arg.split(":", 1)
            task_id = tid_part.strip()
            val = step_part.strip().lower()
            if val in ("completed", "done", "finished"):
                status = "completed"
            elif val.isdigit():
                step_idx = int(val)
        elif arg.isdigit():
            step_idx = int(arg)
        elif arg.lower() in ("completed", "done", "finished"):
            status = "completed"
        elif arg:
            task_id = arg

        if not task_id:
            if task:
                task_id = task["id"]
            else:
                return False, "No active agent task found to update."

        if status == "completed":
            db.complete_agent_task(task_id)
            return True, f"Agent Task [{task_id}] marked as COMPLETED."
        else:
            db.update_agent_task_step(task_id, step_idx, status=status)
            return True, f"Agent Task [{task_id}] updated to Step {step_idx + 1}."
    except Exception as exc:
        return False, f"Failed to update task: {exc}"


def list_agent_tasks() -> ActionResult:
    """Returns a summary of saved agent tasks and goals."""
    try:
        import memory.database as db
        tasks = db.get_all_agent_tasks(limit=10)
        if not tasks:
            return True, "No saved agent tasks found."
        lines = ["Saved Agent Tasks:"]
        for t in tasks:
            st = t["status"].upper()
            cur = t["current_step"] + 1
            tot = len(t.get("steps", []))
            lines.append(f"- [{st}] {t['title']} (Step {cur}/{tot}) [ID: {t['id']}]")
        return True, "\n".join(lines)
    except Exception as exc:
        return False, f"Failed to list tasks: {exc}"



